package com.tst.commandtool;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.List;


public class MapPreviewView extends View {

    private List<CommandSplitter.PlacedBlock> blocks;
    private final Paint cellPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint = new Paint();
    private int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
    private int minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;

    public MapPreviewView(Context c) {
        super(c);
        init();
    }

    public MapPreviewView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        bgPaint.setColor(0xFF111113);
        gridPaint.setColor(0xFF26262b);
        gridPaint.setStrokeWidth(1f);
        setBackgroundColor(Color.TRANSPARENT);
    }

    public void setBlocks(List<CommandSplitter.PlacedBlock> list) {
        this.blocks = list;
        minX = maxX = minZ = maxZ = 0;
        if (list != null) {
            for (CommandSplitter.PlacedBlock b : list) {
                if (b.x < minX) minX = b.x;
                if (b.x > maxX) maxX = b.x;
                if (b.z < minZ) minZ = b.z;
                if (b.z > maxZ) maxZ = b.z;
            }
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        canvas.drawRect(0, 0, w, h, bgPaint);

        if (blocks == null || blocks.isEmpty()) {
            gridPaint.setColor(0xFF4b5563);
            gridPaint.setTextSize(28f);
            canvas.drawText("", 20, h / 2f, gridPaint);
            return;
        }

        int spanX = Math.max(maxX - minX + 1, 1);
        int spanZ = Math.max(maxZ - minZ + 1, 1);
        float cell = Math.min((float) w / spanX, (float) h / spanZ);
        float ox = (w - cell * spanX) / 2f;
        float oy = (h - cell * spanZ) / 2f;

        
        gridPaint.setColor(0xFF1f1f23);
        for (int i = 0; i <= spanX; i++) {
            canvas.drawLine(ox + i * cell, oy, ox + i * cell, oy + spanZ * cell, gridPaint);
        }
        for (int j = 0; j <= spanZ; j++) {
            canvas.drawLine(ox, oy + j * cell, ox + spanX * cell, oy + j * cell, gridPaint);
        }

        for (CommandSplitter.PlacedBlock b : blocks) {
            float cx = ox + (b.x - minX) * cell;
            float cy = oy + (b.z - minZ) * cell;
            cellPaint.setColor(b.color);
            canvas.drawRect(cx + 0.5f, cy + 0.5f, cx + cell - 0.5f, cy + cell - 0.5f, cellPaint);
        }
    }
}
