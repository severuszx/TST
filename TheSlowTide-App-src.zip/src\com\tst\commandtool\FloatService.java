package com.tst.commandtool;

import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class FloatService extends Service implements DeployEngine.Listener {

    public static volatile boolean running = false;

    private WindowManager wm;
    private View ball;
    private View panel;
    private WindowManager.LayoutParams ballParams;
    private WindowManager.LayoutParams panelParams;
    private boolean panelVisible = false;
    private TextView ballText;

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DeployEngine.get().attach(this);
        DeployEngine.get().addListener(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.perm_float_desc, Toast.LENGTH_LONG).show();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ball == null) {
            createBall();
        }
        updateBall();
        return START_STICKY;
    }

    private void createBall() {
        ballText = new TextView(this);
        ballText.setText("TST");
        ballText.setTextColor(0xFFe5e5e7);
        ballText.setTextSize(14f);
        ballText.setTypeface(Typeface.DEFAULT_BOLD);
        ballText.setGravity(Gravity.CENTER);
        ballText.setBackgroundResource(R.drawable.bg_float_ball);
        int size = (int) (48 * getResources().getDisplayMetrics().density);
        ballParams = new WindowManager.LayoutParams(
                size, size,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        ballParams.gravity = Gravity.TOP | Gravity.START;
        ballParams.x = (int) (getResources().getDisplayMetrics().widthPixels * 0.8f);
        ballParams.y = (int) (getResources().getDisplayMetrics().heightPixels * 0.7f);

        ball = ballText;
        ball.setOnTouchListener(new BallTouch());
        wm.addView(ball, ballParams);
    }

    private final class BallTouch implements View.OnTouchListener {
        private int startX, startY;
        private float touchX, touchY;
        private boolean moved;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = ballParams.x;
                    startY = ballParams.y;
                    touchX = e.getRawX();
                    touchY = e.getRawY();
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (e.getRawX() - touchX);
                    int dy = (int) (e.getRawY() - touchY);
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true;
                    ballParams.x = startX + dx;
                    ballParams.y = startY + dy;
                    try {
                        wm.updateViewLayout(ball, ballParams);
                    } catch (Exception ignored) {
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) togglePanel();
                    return true;
            }
            return false;
        }
    }

    private void togglePanel() {
        if (panelVisible) hidePanel();
        else showPanel();
    }

    private void showPanel() {
        if (panel != null) return;
        panel = LayoutInflater.from(this).inflate(R.layout.float_panel, null);
        panelParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = Math.max(0, ballParams.x - (int) (150 * getResources().getDisplayMetrics().density));
        panelParams.y = Math.max(0, ballParams.y - (int) (100 * getResources().getDisplayMetrics().density));

        Button retry = panel.findViewById(R.id.floatBtnRetry);
        Button manual = panel.findViewById(R.id.floatBtnManual);
        Button toggle = panel.findViewById(R.id.floatBtnToggle);
        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeployEngine.get().retryBlock();
                Toast.makeText(FloatService.this,
                        "请将准心对准命令方块并点开", Toast.LENGTH_SHORT).show();
            }
        });
        manual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyCurrentBlock();
            }
        });
        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeployEngine.get().toggle();
            }
        });

        wm.addView(panel, panelParams);
        panelVisible = true;
        updatePanel();
    }

    private void hidePanel() {
        if (panel != null) {
            try {
                wm.removeView(panel);
            } catch (Exception ignored) {
            }
            panel = null;
            panelVisible = false;
        }
    }

    private void copyCurrentBlock() {
        String cmd = DeployEngine.get().currentBlock();
        if (cmd == null) {
            Toast.makeText(this, "当前没有部署任务", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("cmd", cmd));
        Toast.makeText(this, "已复制第 " + (DeployEngine.get().getTask().currentIndex + 1)
                + " 块，请到命令方块输入框长按粘贴", Toast.LENGTH_LONG).show();
    }

    private void updateBall() {
        if (ballText == null) return;
        CommandTask t = DeployEngine.get().getTask();
        if (t == null || t.total() == 0) {
            ballText.setText("TST");
            return;
        }
        if (t.state == CommandTask.STATE_DONE) {
            ballText.setText("✓");
        } else if (t.state == CommandTask.STATE_RUNNING) {
            ballText.setText((t.currentIndex + 1) + "/" + t.total());
        } else if (t.state == CommandTask.STATE_ERROR) {
            ballText.setText("!");
        } else {
            ballText.setText("TST");
        }
    }

    private void updatePanel() {
        if (panel == null) return;
        CommandTask t = DeployEngine.get().getTask();
        TextView title = panel.findViewById(R.id.floatTitle);
        TextView progress = panel.findViewById(R.id.floatProgress);
        TextView log = panel.findViewById(R.id.floatLog);
        View dot = panel.findViewById(R.id.floatStatusDot);
        Button toggle = panel.findViewById(R.id.floatBtnToggle);

        if (t == null || t.total() == 0) {
            title.setText(R.string.float_start_hint);
            progress.setText("");
            dot.setBackgroundResource(R.drawable.bg_float_ball);
            return;
        }
        title.setText(t.name == null || t.name.isEmpty() ? "部署任务" : t.name);
        if (t.state == CommandTask.STATE_RUNNING) {
            progress.setText(getString(R.string.float_running, t.currentIndex + 1, t.total()));
            dot.setBackgroundColor(0xFF4f63d8);
            toggle.setText(R.string.btn_pause_deploy);
        } else if (t.state == CommandTask.STATE_DONE) {
            progress.setText(R.string.float_done);
            dot.setBackgroundColor(0xFF22c55e);
            toggle.setText(R.string.btn_pause_deploy);
        } else if (t.state == CommandTask.STATE_ERROR) {
            progress.setText(getString(R.string.float_failed, t.currentIndex + 1));
            dot.setBackgroundColor(0xFFef4444);
            toggle.setText(R.string.btn_resume_deploy);
        } else {
            progress.setText(getString(R.string.float_running, t.currentIndex + 1, t.total()));
            dot.setBackgroundColor(0xFF9a9aa0);
            toggle.setText(R.string.btn_resume_deploy);
        }
    }

    @Override
    public void onStateChanged() {
        runOnUi(new Runnable() {
            @Override
            public void run() {
                updateBall();
                updatePanel();
            }
        });
    }

    @Override
    public void onLog(String line) {
        runOnUi(new Runnable() {
            @Override
            public void run() {
                if (panel != null) {
                    TextView log = panel.findViewById(R.id.floatLog);
                    log.setText(line);
                }
            }
        });
    }

    private void runOnUi(Runnable r) {
        android.os.Handler h = new android.os.Handler(getMainLooper());
        h.post(r);
    }

    @Override
    public void onDestroy() {
        running = false;
        DeployEngine.get().removeListener(this);
        hidePanel();
        if (ball != null) {
            try {
                wm.removeView(ball);
            } catch (Exception ignored) {
            }
            ball = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
