package com.tst.commandtool;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * 统一账号登录管理：使用官网 theslowtide 账号体系（邮箱 + 验证码）。
 * 接口与主站登录完全一致：
 *   POST /api/send-code {email}
 *   POST /api/verify     {email, code} -> {ok, token, email, uid}
 *   POST /api/admin/users {action:"whoami"} (Authorization: Bearer token) -> admin_level
 */
public class LoginManager {

    public static final String AUTH = "https://theslowtidefk.pages.dev/api";

    private static final String PREFS = "tst_account";
    private static final String KEY_TOKEN = "token";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_UID = "uid";
    private static final String KEY_ADMIN = "admin_level";

    public interface Callback {
        void onResult(boolean ok, String msg, JSONObject data);
    }

    public static String token(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TOKEN, null);
    }

    public static String email(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_EMAIL, null);
    }

    public static String uid(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_UID, null);
    }

    public static int adminLevel(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_ADMIN, 0);
    }

    public static boolean isLoggedIn(Context c) {
        String t = token(c);
        return t != null && !t.isEmpty();
    }

    public static void save(Context c, String token, String email, String uid) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_TOKEN, token)
                .putString(KEY_EMAIL, email)
                .putString(KEY_UID, uid)
                .apply();
    }

    public static void saveAdminLevel(Context c, int level) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putInt(KEY_ADMIN, level).apply();
    }

    public static void logout(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_TOKEN)
                .remove(KEY_EMAIL)
                .remove(KEY_UID)
                .remove(KEY_ADMIN)
                .apply();
    }

    /** 发送验证码 */
    public static void sendCode(final String email, final Callback cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject d = post(AUTH + "/send-code", new JSONObject().put("email", email), null);
                    final JSONObject dd = d;
                    cb.onResult(d != null && d.optBoolean("ok"),
                            d == null ? "网络异常" : d.optString("msg", d.optBoolean("ok") ? "验证码已发送" : "发送失败"),
                            dd);
                } catch (final Exception e) {
                    cb.onResult(false, "网络异常：" + e.getMessage(), null);
                }
            }
        }).start();
    }

    /** 校验验证码并登录 */
    public static void verify(final String email, final String code, final Callback cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject body = new JSONObject();
                    body.put("email", email);
                    body.put("code", code);
                    final JSONObject d = post(AUTH + "/verify", body, null);
                    cb.onResult(d != null && d.optBoolean("ok"),
                            d == null ? "网络异常" : d.optString("msg", d.optBoolean("ok") ? "登录成功" : "验证失败"),
                            d);
                } catch (final Exception e) {
                    cb.onResult(false, "网络异常：" + e.getMessage(), null);
                }
            }
        }).start();
    }

    /** whoami：获取管理员级别 */
    public static void whoami(final Context c, final Callback cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject d = post(AUTH + "/admin/users",
                            new JSONObject().put("action", "whoami"), token(c));
                    if (d != null && d.optBoolean("ok")) {
                        int level = d.optInt("admin_level", 0);
                        saveAdminLevel(c, level);
                        cb.onResult(true, "", d);
                    } else {
                        saveAdminLevel(c, 0);
                        cb.onResult(false, d == null ? "网络异常" : d.optString("msg", "查询失败"), d);
                    }
                } catch (final Exception e) {
                    cb.onResult(false, "网络异常：" + e.getMessage(), null);
                }
            }
        }).start();
    }

    private static JSONObject post(String urlStr, JSONObject body, String bearer) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(12000);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        if (bearer != null && !bearer.isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + bearer);
        }
        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();
        int code = conn.getResponseCode();
        InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (is == null) return null;
        BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        conn.disconnect();
        return new JSONObject(sb.toString());
    }
}
