# Build script: manual Android APK build without Gradle.
# Usage: powershell -ExecutionPolicy Bypass -File build.ps1
$ErrorActionPreference = "Stop"
$proj = "C:\Users\Lenovo\Doubao\chats\2026-09-13\new-chat\TST-CommandTool"
$build = "C:\Users\Lenovo\Doubao\chats\2026-09-13\new-chat\build_apk"
$sdk = "$build\android-sdk"
$platform = "$sdk\platforms\android-33\android.jar"
$buildTools = "$sdk\build-tools\33.0.2"

# JDK 17 from downloaded zip
# Fallback: use system JRE8 + ecj (no javac needed)
$jreBin = "C:\Program Files\Java\jre1.8.0_461\bin"
$javaBin = $jreBin

$out = "$build\out"
New-Item -ItemType Directory -Force $out | Out-Null
New-Item -ItemType Directory -Force "$out\flat" | Out-Null
New-Item -ItemType Directory -Force "$out\classes" | Out-Null
New-Item -ItemType Directory -Force "$out\dex" | Out-Null

# 每次构建前清空编译产物，避免残留旧 class 混入 dex 导致运行时崩溃
Remove-Item "$out\classes\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$out\dex\*" -Force -ErrorAction SilentlyContinue
Remove-Item "$out\*.apk" -Force -ErrorAction SilentlyContinue

Write-Output "== 1/6 compile resources (aapt2) =="
Remove-Item "$out\flat\*" -Force -ErrorAction SilentlyContinue
Get-ChildItem "$proj\res" -Recurse -File | ForEach-Object {
    & "$buildTools\aapt2.exe" compile "$($_.FullName)" -o "$out\flat"
    if ($LASTEXITCODE -ne 0) { throw "aapt2 compile failed: $($_.FullName)" }
}
$flatList = @(Get-ChildItem "$out\flat" -Filter *.flat | ForEach-Object FullName)

Write-Output "== 2/6 link resources =="
& "$buildTools\aapt2.exe" link -o "$out\base.apk" `
    -I $platform `
    --manifest "$proj\AndroidManifest.xml" `
    --java "$out" `
    $flatList
if ($LASTEXITCODE -ne 0) { throw "aapt2 link failed" }

Write-Output "== 2.5/6 inject version =="
$manifestRaw = Get-Content "$proj\AndroidManifest.xml" -Raw
$vc = [regex]::Match($manifestRaw, 'versionCode="(\d+)"').Groups[1].Value
$vn = [regex]::Match($manifestRaw, 'versionName="([^"]+)"').Groups[1].Value
$vmPath = "$proj\src\com\tst\commandtool\VersionManager.java"
$vm = Get-Content -LiteralPath $vmPath -Raw -Encoding utf8
$vm = [regex]::Replace($vm, 'VERSION_CODE = \d+', "VERSION_CODE = $vc")
$vm = [regex]::Replace($vm, 'VERSION_NAME = "[^"]*"', "VERSION_NAME = `"$vn`"")
[IO.File]::WriteAllText($vmPath, $vm, (New-Object Text.UTF8Encoding $false))
Write-Output "injected versionCode=$vc versionName=$vn into VersionManager"

Write-Output "== 3/6 compile java (ecj) =="
$javaFiles = Get-ChildItem "$proj\src" -Recurse -Filter *.java | ForEach-Object FullName
$javaFiles += "$out\com\tst\commandtool\R.java"
$classpath = $platform
& "$javaBin\java.exe" -jar "$build\ecj.jar" -source 1.8 -target 1.8 -encoding UTF-8 `
    -cp $classpath `
    -d "$out\classes" `
    $javaFiles
if ($LASTEXITCODE -ne 0) { throw "ecj failed" }

Write-Output "== 4/6 dex (d8) =="
& "$javaBin\java.exe" -cp "$buildTools\lib\d8.jar" com.android.tools.r8.D8 `
    --release `
    --lib $platform `
    --output "$out\dex" `
    (Get-ChildItem "$out\classes" -Recurse -Filter *.class | ForEach-Object FullName)
if ($LASTEXITCODE -ne 0) { throw "d8 failed" }

Write-Output "== 5/6 package + align =="
# add classes.dex into base.apk
Copy-Item "$out\base.apk" "$out\unsigned.apk" -Force
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open("$out\unsigned.apk", "Update")
$entry = $zip.CreateEntry("classes.dex", [System.IO.Compression.CompressionLevel]::Optimal)
$stream = $entry.Open()
$bytes = [System.IO.File]::ReadAllBytes("$out\dex\classes.dex")
$stream.Write($bytes, 0, $bytes.Length)
$stream.Close()
# add assets (正斜杠条目名，确保 Android AssetManager 可读)
Get-ChildItem "$proj\assets" -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($proj.Length + 1).Replace('\', '/')
    $e = $zip.CreateEntry($rel, [System.IO.Compression.CompressionLevel]::Optimal)
    $s = $e.Open()
    $b = [System.IO.File]::ReadAllBytes($_.FullName)
    $s.Write($b, 0, $b.Length)
    $s.Close()
}
$zip.Dispose()
& "$buildTools\zipalign.exe" -f 4 "$out\unsigned.apk" "$out\aligned.apk"
if ($LASTEXITCODE -ne 0) { throw "zipalign failed" }

Write-Output "== 6/6 sign =="
$ks = "$build\release.keystore"
if (-not (Test-Path $ks)) {
    & "$javaBin\keytool.exe" -genkeypair -v -keystore $ks -alias tst -keyalg RSA -keysize 2048 -validity 10000 -storepass tst123456 -keypass tst123456 -dname "CN=The Slow Tide, OU=TST, O=TST, L=CN, ST=CN, C=CN"
}
& "$javaBin\java.exe" -jar "$buildTools\lib\apksigner.jar" sign `
    --ks $ks --ks-key-alias tst --ks-pass pass:tst123456 --key-pass pass:tst123456 `
    --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true `
    --out "$out\TheSlowTide.apk" "$out\aligned.apk"
if ($LASTEXITCODE -ne 0) { throw "sign failed" }

& "$javaBin\java.exe" -jar "$buildTools\lib\apksigner.jar" verify --print-certs "$out\TheSlowTide.apk"
Write-Output ("APK: " + (Get-Item "$out\TheSlowTide.apk").Length + " bytes")
