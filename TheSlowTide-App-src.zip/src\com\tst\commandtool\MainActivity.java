package com.tst.commandtool;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends Activity {

    private static final String NOTICES_URL = "https://theslowtide.pages.dev/announcements.json";

    private LinearLayout homeGrid;
    private TextView loginStatus, noticeTitle, noticeBrief, meVersion;
    private Button btnLogin;

    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DeployEngine.get().attach(this);

        homeGrid = findViewById(R.id.homeGrid);
        loginStatus = findViewById(R.id.loginStatus);
        noticeTitle = findViewById(R.id.noticeTitle);
        noticeBrief = findViewById(R.id.noticeBrief);
        meVersion = findViewById(R.id.meVersion);
        btnLogin = findViewById(R.id.btnLogin);
        Button btnSource = findViewById(R.id.btnSource);
        Button btnCheckUpdate = findViewById(R.id.btnCheckUpdate);

        buildFeatureGrid();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (LoginManager.isLoggedIn(MainActivity.this)) {
                    logout();
                } else {
                    showLoginDialog();
                }
            }
        });

        btnSource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/severuszx/TST")));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "无法打开浏览器", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCheckUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkUpdate();
            }
        });

        findViewById(R.id.noticeCard).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFeature("notice");
            }
        });

        refreshLoginUi();
        meVersion.setText(getString(R.string.me_version, VersionManager.BuildConfigHolder.VERSION_NAME));
        loadNotices();
        checkUpdateSilent();
    }

    // ===== 功能入口网格 =====

    private void buildFeatureGrid() {
        addEntry("tools", R.string.entry_tools, R.string.entry_tools_sub, "\uD83D\uDD27");
        addEntry("lib", R.string.entry_lib, R.string.entry_lib_sub, "\uD83D\uDCC1");
        addEntry("selector", R.string.entry_selector, R.string.entry_selector_sub, "\u25A1");
        addEntry("base64", R.string.entry_base64, R.string.entry_base64_sub, "\uD83D\uDDBC");
        addEntry("jsonview", R.string.entry_json, R.string.entry_json_sub, "\uD83D\uDCDC");
        addEntry("snowball", R.string.entry_snowball, R.string.entry_snowball_sub, "\u2744");
        addEntry("mcdownload", R.string.entry_mc, R.string.entry_mc_sub, "\u2B07");
        addEntry("sites", R.string.entry_sites, R.string.entry_sites_sub, "\uD83C\uDF10");
        addEntry("skin", R.string.entry_skin, R.string.entry_skin_sub, "\uD83E\uDDD4");
        addEntry("seed", R.string.entry_seed, R.string.entry_seed_sub, "\uD83C\uDF3F");
        addEntry("notice", R.string.entry_notice, R.string.entry_notice_sub, "\uD83D\uDCE3");
        addEntry("site", R.string.entry_site, R.string.entry_site_sub, "\uD83C\uDF0D");
    }

    private void addEntry(final String key, int titleRes, int subRes, String icon) {
        final LinearLayout row;
        LinearLayout lastRow = (LinearLayout) homeGrid.getChildAt(homeGrid.getChildCount() - 1);
        if (lastRow == null || lastRow.getChildCount() >= 2) {
            row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = 8;
            row.setLayoutParams(rlp);
            homeGrid.addView(row);
        } else {
            row = lastRow;
        }

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setBackgroundResource(R.drawable.bg_btn_ghost);
        card.setElevation(1f);
        card.setPadding(10, 14, 10, 14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        if (row.getChildCount() == 0) {
            lp.rightMargin = 4;
        } else {
            lp.leftMargin = 4;
        }
        card.setLayoutParams(lp);
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFeature(key);
            }
        });

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(22f);
        iconView.setGravity(Gravity.CENTER);
        card.addView(iconView);

        TextView title = new TextView(this);
        title.setText(titleRes);
        title.setTextColor(0xFF1f2937);
        title.setTextSize(14f);
        title.setTypeface(title.getTypeface(), 1);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 6, 0, 0);
        card.addView(title);

        TextView sub = new TextView(this);
        sub.setText(subRes);
        sub.setTextColor(0xFF5b6675);
        sub.setTextSize(11f);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 2, 0, 0);
        sub.setMaxLines(1);
        card.addView(sub);

        row.addView(card);
    }

    private void openFeature(String key) {
        Intent i = new Intent(this, FeatureActivity.class);
        i.putExtra(FeatureActivity.EXTRA_FEATURE, key);
        startActivity(i);
    }

    // ===== 登录 =====

    private void refreshLoginUi() {
        if (LoginManager.isLoggedIn(this)) {
            String email = LoginManager.email(this);
            loginStatus.setText(getString(R.string.login_hi, email == null ? "" : email));
            btnLogin.setText(R.string.login_logout);
        } else {
            loginStatus.setText(R.string.login_btn);
            btnLogin.setText(R.string.login_btn);
        }
    }

    private void logout() {
        LoginManager.logout(this);
        Toast.makeText(this, "已退出登录", Toast.LENGTH_SHORT).show();
        refreshLoginUi();
    }

    private void showLoginDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog);
        View v = getLayoutInflater().inflate(R.layout.login_dialog, null);
        builder.setView(v);
        final AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_glass_card);
        }
        final EditText emailEl = v.findViewById(R.id.loginEmail);
        final EditText codeEl = v.findViewById(R.id.loginCode);
        final Button sendBtn = v.findViewById(R.id.loginSendCode);
        final Button confirmBtn = v.findViewById(R.id.loginConfirm);
        final Button cancelBtn = v.findViewById(R.id.loginCancel);
        final TextView msg = v.findViewById(R.id.loginMsg);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                sendBtn.setEnabled(false);
                sendBtn.setText(R.string.login_sending);
                LoginManager.sendCode(email, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                msg.setVisibility(View.VISIBLE);
                                msg.setText(s);
                                if (ok) {
                                    startCountdown(sendBtn);
                                } else {
                                    sendBtn.setEnabled(true);
                                    sendBtn.setText(R.string.login_send_code);
                                }
                            }
                        });
                    }
                });
            }
        });

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                final String code = codeEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                if (code.length() != 6) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_code);
                    return;
                }
                confirmBtn.setEnabled(false);
                LoginManager.verify(email, code, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                confirmBtn.setEnabled(true);
                                if (ok && data != null) {
                                    LoginManager.save(MainActivity.this,
                                            data.optString("token"),
                                            data.optString("email"),
                                            data.optString("uid"));
                                    msg.setText(R.string.login_success);
                                    dialog.dismiss();
                                    Toast.makeText(MainActivity.this, R.string.login_success, Toast.LENGTH_SHORT).show();
                                    refreshLoginUi();
                                    LoginManager.whoami(MainActivity.this, null);
                                } else {
                                    msg.setText(getString(R.string.login_failed, s == null ? "" : s));
                                }
                            }
                        });
                    }
                });
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void startCountdown(final Button btn) {
        final int[] left = {60};
        btn.setText(getString(R.string.login_countdown, left[0]));
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                left[0]--;
                if (left[0] <= 0) {
                    btn.setEnabled(true);
                    btn.setText(R.string.login_send_code);
                } else {
                    btn.setText(getString(R.string.login_countdown, left[0]));
                    ui.postDelayed(this, 1000);
                }
            }
        }, 1000);
    }

    // ===== 主页公告（最新一条）=====

    private void loadNotices() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection)
                            new java.net.URL(NOTICES_URL).openConnection();
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(12000);
                    conn.setRequestMethod("GET");
                    int code = conn.getResponseCode();
                    if (code != 200) return;
                    InputStream is = conn.getInputStream();
                    BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    conn.disconnect();
                    final JSONArray arr = new JSONObject(sb.toString()).optJSONArray("items");
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            renderTopNotice(arr);
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    private void renderTopNotice(JSONArray arr) {
        if (arr == null || arr.length() == 0) return;
        JSONObject n = arr.optJSONObject(0);
        if (n == null) return;
        String title = n.optString("title", "");
        String date = n.optString("date", "");
        String body = n.optString("body", "");
        noticeTitle.setText((date.isEmpty() ? "" : date + "  ") + title);
        noticeBrief.setText(body);
    }

    // ===== 云端版本检查 =====

    private void checkUpdateSilent() {
        VersionManager.check(this, new VersionManager.CheckCallback() {
            @Override
            public void onResult(final boolean hasNew, final JSONObject info, String error) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!hasNew) return;
                        String note = info.optString("note", "");
                        String ver = info.optString("versionName", "");
                        final String url = info.optString("url", "");
                        AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.this);
                        b.setTitle(R.string.update_title);
                        b.setMessage("发现新版本 v" + ver + "\n\n" + note + "\n\n下载安装包将直接在软件内进行。");
                        b.setPositiveButton(R.string.update_now, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                VersionManager.openDownload(MainActivity.this, url);
                            }
                        });
                        b.setNegativeButton(R.string.update_later, null);
                        b.show();
                    }
                });
            }
        });
    }

    private void checkUpdate() {
        Toast.makeText(this, R.string.update_checking, Toast.LENGTH_SHORT).show();
        checkUpdateSilent();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshLoginUi();
    }
}
