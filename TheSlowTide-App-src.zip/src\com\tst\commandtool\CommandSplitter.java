package com.tst.commandtool;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CommandSplitter {

    
    public static final int DEFAULT_LIMIT = 8000;

    
    private static final Pattern SETBLOCK = Pattern.compile(
            "setblock\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)\\s+([\\w:]+)");
    
    private static final Pattern FILL = Pattern.compile(
            "fill\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)\\s+([\\w:]+)");

    
    public static List<String> split(String cmd, int limit) {
        List<String> result = new ArrayList<>();
        if (cmd == null || cmd.trim().isEmpty()) return result;
        String text = cmd.trim().replace("\n", " ").replaceAll("\\s+", " ");

        
        List<String> clauses = splitClauses(text);
        
        StringBuilder buf = new StringBuilder();
        for (String c : clauses) {
            if (buf.length() > 0 && buf.length() + 1 + c.length() > limit) {
                result.add(buf.toString().trim());
                buf.setLength(0);
            }
            if (c.length() > limit) {
                
                if (buf.length() > 0) {
                    result.add(buf.toString().trim());
                    buf.setLength(0);
                }
                String rest = c;
                while (rest.length() > limit) {
                    result.add(rest.substring(0, limit));
                    rest = rest.substring(limit);
                }
                if (!rest.isEmpty()) buf.append(rest);
            } else {
                if (buf.length() > 0) buf.append(' ');
                buf.append(c);
            }
        }
        if (buf.length() > 0) result.add(buf.toString().trim());
        return result;
    }

    private static List<String> splitClauses(String text) {
        List<String> clauses = new ArrayList<>();
        
        int idx = 0;
        String lower = text.toLowerCase();
        while (idx < text.length()) {
            int next = lower.indexOf("execute ", idx + 1);
            if (next < 0) {
                clauses.add(text.substring(idx).trim());
                break;
            }
            String clause = text.substring(idx, next).trim();
            if (!clause.isEmpty()) clauses.add(clause);
            idx = next;
        }
        if (clauses.isEmpty()) clauses.add(text.trim());
        return clauses;
    }

    
    public static class PlacedBlock {
        public int x, y, z;
        public String block;
        public int color;
        public PlacedBlock(int x, int y, int z, String block, int color) {
            this.x = x; this.y = y; this.z = z; this.block = block; this.color = color;
        }
    }

    
    public static List<PlacedBlock> parseLayout(String cmd) {
        List<PlacedBlock> list = new ArrayList<>();
        if (cmd == null) return list;
        Matcher m = SETBLOCK.matcher(cmd);
        while (m.find()) {
            int x = Integer.parseInt(m.group(1));
            int y = Integer.parseInt(m.group(2));
            int z = Integer.parseInt(m.group(3));
            String b = m.group(4);
            list.add(new PlacedBlock(x, y, z, b, blockColor(b)));
        }
        Matcher f = FILL.matcher(cmd);
        while (f.find()) {
            int x1 = Integer.parseInt(f.group(1));
            int y1 = Integer.parseInt(f.group(2));
            int z1 = Integer.parseInt(f.group(3));
            int x2 = Integer.parseInt(f.group(4));
            int y2 = Integer.parseInt(f.group(5));
            int z2 = Integer.parseInt(f.group(6));
            String b = f.group(7);
            int col = blockColor(b);
            int xMin = Math.min(x1, x2), xMax = Math.max(x1, x2);
            int zMin = Math.min(z1, z2), zMax = Math.max(z1, z2);
            int cap = 200000;
            int total = (xMax - xMin + 1) * (zMax - zMin + 1);
            if (total > cap) {
                
                list.add(new PlacedBlock(xMin, y1, zMin, b, col));
                list.add(new PlacedBlock(xMax, y1, zMax, b, col));
                continue;
            }
            for (int x = xMin; x <= xMax; x++) {
                for (int z = zMin; z <= zMax; z++) {
                    list.add(new PlacedBlock(x, y1, z, b, col));
                }
            }
        }
        return list;
    }

    
    public static int blockColor(String block) {
        String b = block.toLowerCase();
        if (b.contains("white_concrete") || b.contains("white_wool")) return 0xFFF1F5F9;
        if (b.contains("black_concrete") || b.contains("black_wool")) return 0xFF18181b;
        if (b.contains("gray_concrete") || b.contains("gray_wool") || b.contains("light_gray_concrete") || b.contains("light_gray_wool")) return 0xFF9a9aa0;
        if (b.contains("red_concrete") || b.contains("red_wool")) return 0xFFef4444;
        if (b.contains("orange_concrete") || b.contains("orange_wool")) return 0xFFf59e0b;
        if (b.contains("yellow_concrete") || b.contains("yellow_wool")) return 0xFFfde047;
        if (b.contains("lime_concrete") || b.contains("lime_wool")) return 0xFF84cc16;
        if (b.contains("green_concrete") || b.contains("green_wool")) return 0xFF22c55e;
        if (b.contains("cyan_concrete") || b.contains("cyan_wool")) return 0xFF22d3ee;
        if (b.contains("light_blue_concrete") || b.contains("light_blue_wool")) return 0xFF60a5fa;
        if (b.contains("blue_concrete") || b.contains("blue_wool")) return 0xFF2563eb;
        if (b.contains("purple_concrete") || b.contains("purple_wool")) return 0xFF8b5cf6;
        if (b.contains("magenta_concrete") || b.contains("magenta_wool")) return 0xFFc026d3;
        if (b.contains("pink_concrete") || b.contains("pink_wool")) return 0xFFf9a8d4;
        if (b.contains("brown_concrete") || b.contains("brown_wool")) return 0xFF78350f;
        if (b.contains("diamond_block")) return 0xFF22d3ee;
        if (b.contains("emerald_block")) return 0xFF10b981;
        if (b.contains("gold_block")) return 0xFFf59e0b;
        if (b.contains("iron_block")) return 0xFFd1d5db;
        if (b.contains("lapis_block")) return 0xFF1e40af;
        if (b.contains("redstone_block")) return 0xFFdc2626;
        if (b.contains("quartz_block")) return 0xFFf8fafc;
        if (b.contains("glass")) return 0xFF7ea2ff;
        if (b.contains("log") || b.contains("planks")) return 0xFF92400e;
        if (b.contains("stone_brick") || b.contains("cobblestone") || b.contains("stone")) return 0xFF78716c;
        if (b.contains("netherite")) return 0xFF292524;
        if (b.contains("bedrock")) return 0xFF1c1917;
        if (b.contains("sea_lantern") || b.contains("shroomlight")) return 0xFFfef3c7;
        if (b.contains("copper")) return 0xFFb45309;
        if (b.contains("amethyst")) return 0xFFa78bfa;
        if (b.contains("terracotta")) return 0xFFb45309;
        if (b.contains("wool")) return 0xFFe5e5e7;
        return 0xFF6b7280;
    }
}
