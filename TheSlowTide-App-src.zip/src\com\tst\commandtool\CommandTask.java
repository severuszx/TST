package com.tst.commandtool;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class CommandTask {
    public String id;
    public String name;
    public List<String> blocks = new ArrayList<>();
    public int currentIndex = 0;
    public int state = STATE_IDLE; 

    public static final int STATE_IDLE = 0;
    public static final int STATE_RUNNING = 1;
    public static final int STATE_PAUSED = 2;
    public static final int STATE_DONE = 3;
    public static final int STATE_ERROR = 4;

    public CommandTask() {
        this.id = "t" + System.currentTimeMillis();
    }

    public CommandTask(String id) {
        this.id = id;
    }

    public int total() {
        return blocks.size();
    }

    public String currentBlock() {
        if (blocks.isEmpty() || currentIndex < 0 || currentIndex >= blocks.size()) return null;
        return blocks.get(currentIndex);
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("name", name);
            o.put("currentIndex", currentIndex);
            o.put("state", state);
            JSONArray arr = new JSONArray();
            for (String b : blocks) arr.put(b);
            o.put("blocks", arr);
        } catch (Exception ignored) {
        }
        return o;
    }

    public static CommandTask fromJson(JSONObject o) {
        CommandTask t = new CommandTask(o.optString("id", "t" + System.currentTimeMillis()));
        t.name = o.optString("name", "");
        t.currentIndex = o.optInt("currentIndex", 0);
        t.state = o.optInt("state", STATE_IDLE);
        JSONArray arr = o.optJSONArray("blocks");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) t.blocks.add(arr.optString(i));
        }
        return t;
    }
}
