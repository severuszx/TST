package com.tst.commandtool;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_TXT = 1001;

    private static final String TEMPLATES_URL = "https://theslowtide.pages.dev/templates.txt";
    private static final String NOTICES_URL = "https://theslowtide.pages.dev/announcements.json";
    private static final String SITE_URL = "https://theslowtide.pages.dev/mobile.html";
    private static final String SOURCE_URL = "https://github.com/severuszx/TST";

    private EditText cmdInput;
    private LinearLayout splitResultBox;
    private LinearLayout taskListBox;
    private TextView accessState;
    private EditText setBlockLimit, setModeWords, setCondWords, setRedstoneWords;
    private List<CommandTask> tasks;

    // 选区助手
    private EditText selX1, selY1, selZ1, selX2, selY2, selZ2, selTarget, selBlock;
    private TextView selectResult;

    // 指令库
    private TextView libHint;
    private EditText libSearch;
    private LinearLayout libBox;
    private List<String[]> library = new ArrayList<>();

    // 我的
    private TextView loginStatus;
    private Button btnLogin;
    private TextView noticeHint;
    private LinearLayout noticeBox;
    private TextView meVersion;

    // 官网
    private FrameLayout pageSite;
    private WebView webView;
    private boolean webViewCreated = false;

    // Tab
    private View pageTools, pageLib, pageMe;
    private Button btnTabTools, btnTabLib, btnTabSite, btnTabMe;

    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DeployEngine.get().attach(this);

        cmdInput = findViewById(R.id.cmdInput);
        splitResultBox = findViewById(R.id.splitResultBox);
        taskListBox = findViewById(R.id.taskListBox);
        accessState = findViewById(R.id.accessState);
        setBlockLimit = findViewById(R.id.setBlockLimit);
        setModeWords = findViewById(R.id.setModeWords);
        setCondWords = findViewById(R.id.setCondWords);
        setRedstoneWords = findViewById(R.id.setRedstoneWords);

        selX1 = findViewById(R.id.selX1);
        selY1 = findViewById(R.id.selY1);
        selZ1 = findViewById(R.id.selZ1);
        selX2 = findViewById(R.id.selX2);
        selY2 = findViewById(R.id.selY2);
        selZ2 = findViewById(R.id.selZ2);
        selTarget = findViewById(R.id.selTarget);
        selBlock = findViewById(R.id.selBlock);
        selectResult = findViewById(R.id.selectResult);

        libHint = findViewById(R.id.libHint);
        libSearch = findViewById(R.id.libSearch);
        libBox = findViewById(R.id.libBox);

        loginStatus = findViewById(R.id.loginStatus);
        btnLogin = findViewById(R.id.btnLogin);
        noticeHint = findViewById(R.id.noticeHint);
        noticeBox = findViewById(R.id.noticeBox);
        meVersion = findViewById(R.id.meVersion);

        pageTools = findViewById(R.id.pageTools);
        pageLib = findViewById(R.id.pageLib);
        pageSite = findViewById(R.id.pageSite);
        pageMe = findViewById(R.id.pageMe);

        btnTabTools = findViewById(R.id.btnTabTools);
        btnTabLib = findViewById(R.id.btnTabLib);
        btnTabSite = findViewById(R.id.btnTabSite);
        btnTabMe = findViewById(R.id.btnTabMe);

        Button btnPaste = findViewById(R.id.btnPaste);
        Button btnImportTxt = findViewById(R.id.btnImportTxt);
        Button btnSplit = findViewById(R.id.btnSplit);
        Button btnFloat = findViewById(R.id.btnFloat);
        Button btnPermFloat = findViewById(R.id.btnPermFloat);
        Button btnPermAccess = findViewById(R.id.btnPermAccess);
        Button btnSaveSettings = findViewById(R.id.btnSaveSettings);
        Button btnGenSelector = findViewById(R.id.btnGenSelector);
        Button btnGenFill = findViewById(R.id.btnGenFill);
        Button btnLibRefresh = findViewById(R.id.btnLibRefresh);
        Button btnSource = findViewById(R.id.btnSource);
        Button btnCheckUpdate = findViewById(R.id.btnCheckUpdate);

        btnTabTools.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage(0);
            }
        });
        btnTabLib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage(1);
            }
        });
        btnTabSite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage(2);
            }
        });
        btnTabMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage(3);
            }
        });

        btnPaste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm.hasPrimaryClip()) {
                    CharSequence text = cm.getPrimaryClip().getItemAt(0).getText();
                    if (text != null) cmdInput.setText(text.toString());
                }
            }
        });

        btnImportTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/plain");
                try {
                    startActivityForResult(i, REQ_TXT);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSplit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doSplit();
            }
        });

        btnFloat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleFloat();
            }
        });

        btnPermFloat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFloatPermission();
            }
        });

        btnPermAccess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAccessibilitySettings();
            }
        });

        btnSaveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });

        btnGenSelector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genSelector();
            }
        });
        btnGenFill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genFill();
            }
        });

        btnLibRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadLibrary();
            }
        });
        libSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                renderLibrary();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (LoginManager.isLoggedIn(MainActivity.this)) {
                    logout();
                } else {
                    showLoginDialog();
                }
            }
        });

        btnSource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SOURCE_URL)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "无法打开浏览器", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCheckUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkUpdate();
            }
        });

        loadSettingsIntoUi();
        loadTasks();
        updateFloatButton();
        refreshLoginUi();
        loadLibrary();
        loadNotices();
        meVersion.setText(getString(R.string.me_version, VersionManager.BuildConfigHolder.VERSION_NAME));
        showPage(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTasks();
        updateFloatButton();
        refreshLoginUi();
        updateAccessState();
    }

    // ===== Tab 切换 =====

    private void showPage(int idx) {
        pageTools.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        pageLib.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        pageSite.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        pageMe.setVisibility(idx == 3 ? View.VISIBLE : View.GONE);
        if (idx == 2) ensureWebView();
        if (idx == 1 && library.isEmpty()) loadLibrary();
    }

    // ===== 登录 =====

    private void refreshLoginUi() {
        if (LoginManager.isLoggedIn(this)) {
            String email = LoginManager.email(this);
            loginStatus.setText(getString(R.string.login_hi, email == null ? "" : email));
            btnLogin.setText(R.string.login_logout);
        } else {
            loginStatus.setText(R.string.login_btn);
            btnLogin.setText(R.string.login_btn);
        }
    }

    private void logout() {
        LoginManager.logout(this);
        Toast.makeText(this, "已退出登录", Toast.LENGTH_SHORT).show();
        refreshLoginUi();
    }

    private void showLoginDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog);
        View v = getLayoutInflater().inflate(R.layout.login_dialog, null);
        builder.setView(v);
        final AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_glass_card);
        }
        final EditText emailEl = v.findViewById(R.id.loginEmail);
        final EditText codeEl = v.findViewById(R.id.loginCode);
        final Button sendBtn = v.findViewById(R.id.loginSendCode);
        final Button confirmBtn = v.findViewById(R.id.loginConfirm);
        final Button cancelBtn = v.findViewById(R.id.loginCancel);
        final TextView msg = v.findViewById(R.id.loginMsg);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                sendBtn.setEnabled(false);
                sendBtn.setText(R.string.login_sending);
                LoginManager.sendCode(email, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                msg.setVisibility(View.VISIBLE);
                                msg.setText(s);
                                if (ok) {
                                    startCountdown(sendBtn);
                                } else {
                                    sendBtn.setEnabled(true);
                                    sendBtn.setText(R.string.login_send_code);
                                }
                            }
                        });
                    }
                });
            }
        });

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                final String code = codeEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                if (code.length() != 6) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_code);
                    return;
                }
                confirmBtn.setEnabled(false);
                LoginManager.verify(email, code, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                confirmBtn.setEnabled(true);
                                if (ok && data != null) {
                                    LoginManager.save(MainActivity.this,
                                            data.optString("token"),
                                            data.optString("email"),
                                            data.optString("uid"));
                                    msg.setText(R.string.login_success);
                                    dialog.dismiss();
                                    Toast.makeText(MainActivity.this, R.string.login_success, Toast.LENGTH_SHORT).show();
                                    refreshLoginUi();
                                    LoginManager.whoami(MainActivity.this, null);
                                } else {
                                    msg.setText(getString(R.string.login_failed, s == null ? "" : s));
                                }
                            }
                        });
                    }
                });
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void startCountdown(final Button btn) {
        final int[] left = {60};
        btn.setText(getString(R.string.login_countdown, left[0]));
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                left[0]--;
                if (left[0] <= 0) {
                    btn.setEnabled(true);
                    btn.setText(R.string.login_send_code);
                } else {
                    btn.setText(getString(R.string.login_countdown, left[0]));
                    ui.postDelayed(this, 1000);
                }
            }
        }, 1000);
    }

    // ===== 指令库（官网 templates.txt 自动读取）=====

    private void loadLibrary() {
        libHint.setText(R.string.lib_loading);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection)
                            new java.net.URL(TEMPLATES_URL).openConnection();
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(12000);
                    conn.setRequestMethod("GET");
                    int code = conn.getResponseCode();
                    if (code != 200) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                libHint.setText(getString(R.string.lib_fail, "HTTP " + code));
                            }
                        });
                        return;
                    }
                    InputStream is = conn.getInputStream();
                    BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                    final List<String[]> list = new ArrayList<>();
                    String line;
                    while ((line = r.readLine()) != null) {
                        line = line.trim();
                        if (line.isEmpty() || line.startsWith("#")) continue;
                        String[] parts = line.split("\\|", 3);
                        if (parts.length >= 3) {
                            list.add(new String[]{parts[0].trim(), parts[1].trim(), parts[2].trim()});
                        }
                    }
                    r.close();
                    conn.disconnect();
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            library = list;
                            libHint.setText(getString(R.string.lib_hint));
                            renderLibrary();
                            if (library.isEmpty()) {
                                Toast.makeText(MainActivity.this, R.string.lib_empty, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } catch (final Exception e) {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            libHint.setText(getString(R.string.lib_fail, e.getMessage()));
                        }
                    });
                }
            }
        }).start();
    }

    private void renderLibrary() {
        libBox.removeAllViews();
        String q = libSearch.getText().toString().trim().toLowerCase();
        int shown = 0;
        for (final String[] item : library) {
            if (!q.isEmpty() && !item[0].toLowerCase().contains(q)
                    && !item[1].toLowerCase().contains(q)
                    && !item[2].toLowerCase().contains(q)) {
                continue;
            }
            shown++;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_input);
            card.setPadding(12, 10, 12, 10);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 8;
            card.setLayoutParams(lp);

            TextView name = new TextView(this);
            name.setText(item[0]);
            name.setTextColor(0xFFe5e5e7);
            name.setTextSize(14f);
            name.setTypeface(name.getTypeface(), 1);
            card.addView(name);

            TextView desc = new TextView(this);
            desc.setText(item[1]);
            desc.setTextColor(0xFF9a9aa0);
            desc.setTextSize(12f);
            card.addView(desc);

            final String cmd = item[2];
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("tpl", cmd));
                    cmdInput.setText(cmd);
                    Toast.makeText(MainActivity.this,
                            getString(R.string.lib_copied, item[0]), Toast.LENGTH_SHORT).show();
                }
            });
            libBox.addView(card);
        }
        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText(R.string.lib_empty);
            empty.setTextColor(0xFF9a9aa0);
            empty.setTextSize(12f);
            empty.setPadding(0, 8, 0, 8);
            libBox.addView(empty);
        }
    }

    // ===== 更新公告（announcements.json）=====

    private void loadNotices() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection)
                            new java.net.URL(NOTICES_URL).openConnection();
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(12000);
                    conn.setRequestMethod("GET");
                    int code = conn.getResponseCode();
                    if (code != 200) return;
                    InputStream is = conn.getInputStream();
                    BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    conn.disconnect();
                    final JSONArray arr = new JSONObject(sb.toString()).optJSONArray("items");
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            renderNotices(arr);
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    private void renderNotices(JSONArray arr) {
        noticeBox.removeAllViews();
        if (arr == null || arr.length() == 0) {
            noticeHint.setText(R.string.me_notice_empty);
            return;
        }
        noticeHint.setVisibility(View.GONE);
        for (int i = 0; i < arr.length(); i++) {
            final JSONObject n = arr.optJSONObject(i);
            if (n == null) continue;
            final String title = n.optString("title", "");
            final String date = n.optString("date", "");
            final String body = n.optString("body", "");
            final String url = n.optString("url", "");
            final String ver = n.optString("version", "");
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_input);
            card.setPadding(12, 10, 12, 10);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 8;
            card.setLayoutParams(lp);

            TextView t = new TextView(this);
            t.setText((date.isEmpty() ? "" : date + "  ") + title);
            t.setTextColor(0xFFe5e5e7);
            t.setTextSize(13f);
            t.setTypeface(t.getTypeface(), 1);
            card.addView(t);

            if (!body.isEmpty()) {
                TextView b = new TextView(this);
                b.setText(body);
                b.setTextColor(0xFF9a9aa0);
                b.setTextSize(12f);
                card.addView(b);
            }

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.this);
                    b.setTitle(title.isEmpty() ? "公告" : title);
                    b.setMessage(body + (url.isEmpty() ? "" : "\n\n下载链接：" + url));
                    if (!url.isEmpty()) {
                        b.setPositiveButton(R.string.btn_download, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                VersionManager.openDownload(MainActivity.this, url);
                            }
                        });
                    }
                    b.setNegativeButton(R.string.login_cancel, null);
                    b.show();
                }
            });
            noticeBox.addView(card);
        }
    }

    // ===== 官网 WebView =====

    private void ensureWebView() {
        if (webViewCreated) return;
        webViewCreated = true;
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        webView.setBackgroundColor(0xFF0d1016);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                injectLoginState();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    if (url.contains("theslowtide") || url.contains("theslowtidefk")
                            || url.contains("tst")) {
                        view.loadUrl(url);
                        return true;
                    }
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        pageSite.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webView.loadUrl(SITE_URL);
    }

    private void injectLoginState() {
        if (webView == null || !LoginManager.isLoggedIn(this)) return;
        String token = LoginManager.token(this);
        String email = LoginManager.email(this);
        String uid = LoginManager.uid(this);
        if (token == null) return;
        final String js = "try{"
                + "localStorage.setItem('tst_token','" + jsEsc(token) + "');"
                + "localStorage.setItem('tst_email','" + jsEsc(email == null ? "" : email) + "');"
                + "localStorage.setItem('tst_uid','" + jsEsc(uid == null ? "" : uid) + "');"
                + "}catch(e){}";
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript(js, null);
            }
        });
    }

    private String jsEsc(String s) {
        return s.replace("\\", "\\\\").replace("'", "\\'");
    }

    // ===== 选区助手 =====

    private int selInt(EditText e) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (Exception ex) {
            return Integer.MIN_VALUE;
        }
    }

    private void genSelector() {
        int x1 = selInt(selX1), y1 = selInt(selY1), z1 = selInt(selZ1);
        int x2 = selInt(selX2), y2 = selInt(selY2), z2 = selInt(selZ2);
        if (x1 == Integer.MIN_VALUE || x2 == Integer.MIN_VALUE
                || y1 == Integer.MIN_VALUE || y2 == Integer.MIN_VALUE
                || z1 == Integer.MIN_VALUE || z2 == Integer.MIN_VALUE) {
            selectResult.setText("先把两个角的坐标填满");
            return;
        }
        String target = selTarget.getText().toString().trim();
        if (target.isEmpty()) target = "@a";
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int dz = Math.abs(z2 - z1);
        int minX = Math.min(x1, x2), minY = Math.min(y1, y2), minZ = Math.min(z1, z2);
        String sel = target + "[x=" + minX + ",y=" + minY + ",z=" + minZ
                + ",dx=" + dx + ",dy=" + dy + ",dz=" + dz + "]";
        showSelectResult(sel);
    }

    private void genFill() {
        int x1 = selInt(selX1), y1 = selInt(selY1), z1 = selInt(selZ1);
        int x2 = selInt(selX2), y2 = selInt(selY2), z2 = selInt(selZ2);
        if (x1 == Integer.MIN_VALUE || x2 == Integer.MIN_VALUE
                || y1 == Integer.MIN_VALUE || y2 == Integer.MIN_VALUE
                || z1 == Integer.MIN_VALUE || z2 == Integer.MIN_VALUE) {
            selectResult.setText("先把两个角的坐标填满");
            return;
        }
        String block = selBlock.getText().toString().trim();
        if (block.isEmpty()) block = "glass";
        int minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
        int minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
        int minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);
        String cmd = "/fill " + minX + " " + minY + " " + minZ + " "
                + maxX + " " + maxY + " " + maxZ + " " + block;
        showSelectResult(cmd);
    }

    private void showSelectResult(final String text) {
        selectResult.setText(text);
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("sel", text));
        Toast.makeText(this, "已复制到剪贴板", Toast.LENGTH_SHORT).show();
    }

    // ===== 无障碍状态 =====

    private void updateAccessState() {
        boolean on = isAccessibilityEnabled();
        accessState.setText(on ? R.string.access_state_on : R.string.access_state_off);
    }

    private boolean isAccessibilityEnabled() {
        try {
            android.view.accessibility.AccessibilityManager am =
                    (android.view.accessibility.AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            List<AccessibilityServiceInfo> list =
                    am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
            for (AccessibilityServiceInfo info : list) {
                if (info.getResolveInfo().serviceInfo.packageName.equals(getPackageName())) {
                    return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    // ===== 云端版本检查 =====

    private void checkUpdate() {
        Toast.makeText(this, R.string.update_checking, Toast.LENGTH_SHORT).show();
        VersionManager.check(this, new VersionManager.CheckCallback() {
            @Override
            public void onResult(final boolean hasNew, final JSONObject info, String error) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!hasNew) {
                            Toast.makeText(MainActivity.this, "已经是最新版", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        String note = info.optString("note", "");
                        String ver = info.optString("versionName", "");
                        final String url = info.optString("url", "");
                        AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.this);
                        b.setTitle(R.string.update_title);
                        b.setMessage("新版本 v" + ver + "\n\n" + note + "\n\n(下载链接：" + url + ")");
                        b.setPositiveButton(R.string.update_now, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                VersionManager.openDownload(MainActivity.this, url);
                            }
                        });
                        b.setNegativeButton(R.string.update_later, null);
                        b.show();
                    }
                });
            }
        });
    }

    // ===== 原有功能 =====

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_TXT && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) readTxt(uri);
        }
    }

    private void readTxt(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            if (is == null) return;
            BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line).append('\n');
            }
            r.close();
            cmdInput.setText(sb.toString());
        } catch (Exception e) {
            Toast.makeText(this, "读取文件失败", Toast.LENGTH_SHORT).show();
        }
    }

    private void doSplit() {
        String raw = cmdInput.getText().toString();
        if (raw.trim().isEmpty()) {
            Toast.makeText(this, "请先输入指令", Toast.LENGTH_SHORT).show();
            return;
        }
        int limit = parseLimit();
        List<String> blocks = CommandSplitter.split(raw, limit);
        splitResultBox.removeAllViews();
        splitResultBox.setVisibility(View.VISIBLE);

        TextView head = new TextView(this);
        head.setText("共拆成 " + blocks.size() + " 块（单块上限 " + limit + " 字符）");
        head.setTextColor(0xFF9a9aa0);
        head.setTextSize(12f);
        head.setPadding(0, 8, 0, 8);
        splitResultBox.addView(head);

        for (int i = 0; i < blocks.size(); i++) {
            final String block = blocks.get(i);
            TextView card = new TextView(this);
            card.setText((i + 1) + "/" + blocks.size() + " · " + block.length() + " 字符\n" + block);
            card.setTextColor(0xFFe5e5e7);
            card.setTextSize(12f);
            card.setBackgroundResource(R.drawable.bg_input);
            card.setPadding(12, 10, 12, 10);
            card.setGravity(Gravity.START);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 8;
            card.setLayoutParams(lp);
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("cmd", block));
                    Toast.makeText(MainActivity.this, "已复制该块指令", Toast.LENGTH_SHORT).show();
                }
            });
            splitResultBox.addView(card);
        }

        CommandTask t = new CommandTask();
        t.name = "部署任务 " + (tasks.size() + 1);
        t.blocks.addAll(blocks);
        tasks.add(t);
        TaskStore.saveTasks(this, tasks);
        loadTasks();

        List<CommandSplitter.PlacedBlock> layout = CommandSplitter.parseLayout(raw);
        MapPreviewView mv = findViewById(R.id.mapView);
        mv.setBlocks(layout);
        TextView mi = findViewById(R.id.mapInfo);
        mi.setText("解析到 " + layout.size() + " 个方块放置点（setblock/fill）");
    }

    private int parseLimit() {
        try {
            int v = Integer.parseInt(setBlockLimit.getText().toString().trim());
            return v > 0 ? v : CommandSplitter.DEFAULT_LIMIT;
        } catch (Exception e) {
            return CommandSplitter.DEFAULT_LIMIT;
        }
    }

    private void loadTasks() {
        tasks = TaskStore.loadTasks(this);
        taskListBox.removeAllViews();
        if (tasks.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(R.string.empty_tasks);
            empty.setTextColor(0xFF9a9aa0);
            empty.setTextSize(12f);
            empty.setPadding(0, 8, 0, 8);
            taskListBox.addView(empty);
            return;
        }
        for (int i = 0; i < tasks.size(); i++) {
            addTaskCard(tasks.get(i));
        }
    }

    private void addTaskCard(final CommandTask t) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setBackgroundResource(R.drawable.bg_input);
        card.setPadding(12, 10, 12, 10);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 8;
        card.setLayoutParams(lp);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        info.setLayoutParams(infoLp);

        TextView name = new TextView(this);
        name.setText(t.name + " · " + t.total() + " 块");
        name.setTextColor(0xFFe5e5e7);
        name.setTextSize(13f);
        info.addView(name);

        TextView state = new TextView(this);
        String st;
        if (t.state == CommandTask.STATE_DONE) st = "已完成";
        else if (t.state == CommandTask.STATE_RUNNING) st = "部署中 " + (t.currentIndex + 1) + "/" + t.total();
        else if (t.state == CommandTask.STATE_ERROR) st = "出错（第 " + (t.currentIndex + 1) + " 块）";
        else if (t.state == CommandTask.STATE_PAUSED) st = "已暂停";
        else st = "待部署";
        state.setText(st);
        state.setTextColor(0xFF9a9aa0);
        state.setTextSize(12f);
        info.addView(state);
        card.addView(info);

        Button start = new Button(this);
        start.setText("开始");
        start.setBackgroundResource(R.drawable.bg_btn_ghost);
        start.setTextColor(0xFFe5e5e7);
        start.setTextSize(12f);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeployEngine.get().setTask(t);
                DeployEngine.get().start();
                ensureFloat();
                Toast.makeText(MainActivity.this,
                        "请开启悬浮窗与无障碍服务，然后进入游戏：对准命令方块点开，自动部署。第 1 块就绪",
                        Toast.LENGTH_LONG).show();
                loadTasks();
            }
        });
        card.addView(start);

        Button del = new Button(this);
        del.setText("删除");
        del.setBackgroundResource(R.drawable.bg_btn_ghost);
        del.setTextColor(0xFF9a9aa0);
        del.setTextSize(12f);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tasks.remove(t);
                TaskStore.saveTasks(MainActivity.this, tasks);
                loadTasks();
            }
        });
        card.addView(del);

        taskListBox.addView(card);
    }

    private void ensureFloat() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            openFloatPermission();
            return;
        }
        startService(new Intent(this, FloatService.class));
    }

    private void toggleFloat() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            openFloatPermission();
            return;
        }
        if (FloatService.running) {
            stopService(new Intent(this, FloatService.class));
        } else {
            startService(new Intent(this, FloatService.class));
        }
        updateFloatButton();
    }

    private void updateFloatButton() {
        Button btnFloat = findViewById(R.id.btnFloat);
        if (FloatService.running) {
            btnFloat.setText(R.string.btn_stop_float);
        } else {
            btnFloat.setText(R.string.btn_start_float);
        }
    }

    private void openFloatPermission() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }
    }

    private void openAccessibilitySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void loadSettingsIntoUi() {
        JSONObject s = TaskStore.loadSettings(this);
        setBlockLimit.setText(String.valueOf(s.optInt("blockLimit", CommandSplitter.DEFAULT_LIMIT)));
        setModeWords.setText(s.optString("modeWords", "普通,循环,连锁"));
        setCondWords.setText(s.optString("condWords", "无条件,有条件的"));
        setRedstoneWords.setText(s.optString("redstoneWords", "需要红石,不需要红石"));
    }

    private void saveSettings() {
        JSONObject s = new JSONObject();
        try {
            s.put("blockLimit", parseLimit());
            s.put("modeWords", setModeWords.getText().toString().trim());
            s.put("condWords", setCondWords.getText().toString().trim());
            s.put("redstoneWords", setRedstoneWords.getText().toString().trim());
            s.put("targetMode", firstWord(setModeWords.getText().toString()));
            s.put("targetCond", firstWord(setCondWords.getText().toString()));
            s.put("targetRedstone", firstWord(setRedstoneWords.getText().toString()));
            s.put("autoVerify", true);
        } catch (Exception ignored) {
        }
        TaskStore.saveSettings(this, s);
        DeployEngine.get().attach(this);
        Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
    }

    private String firstWord(String s) {
        if (s == null) return "";
        String[] parts = s.split(",");
        return parts.length > 0 ? parts[0].trim() : "";
    }

    @Override
    public void onBackPressed() {
        if (pageSite.getVisibility() == View.VISIBLE && webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            pageSite.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
