package com.tst.commandtool;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Path;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * 自动部署无障碍服务（网易版增强）：
 * 1. 窗口判定增加「游戏自绘 UI」通道：网易基岩版命令方块界面常由 SurfaceView 自绘，
 *    无障碍树里没有 EditText，原版会直接判「不像命令方块界面」而毫无反应。
 *    现增加：部署运行中 + 弹出新窗口 + 根节点为全屏 Surface/Texture/ViewGroup 时，视为候选界面。
 * 2. 输入框多通道定位：EditText 类名 / TextInput / 可聚焦 / contentDescription / viewId；
 * 3. 找不到输入框时：坐标点击兜底（模拟点击屏幕中央偏上，触发网易版内嵌输入框光标），再找一次；
 * 4. 仍失败：把指令复制到剪贴板并提示手动粘贴，不静默失败；
 * 5. 填充多通道重试：FOCUS -> CLICK -> PASTE -> SET_TEXT，粘贴后再校验；
 * 6. 模式/条件/红石设置为包含匹配，兼容网易版控件文案；
 * 7. 严格节点回收。
 */
public class DeployAccessibilityService extends AccessibilityService {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastHandledAt = 0;
    private boolean deploying = false;

    private static final long MIN_INTERVAL_MS = 1500;
    private static final long OPEN_DELAY_MS = 800;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            return;
        }
        DeployEngine engine = DeployEngine.get();
        engine.attach(this);
        if (!engine.isRunning()) return;

        long now = System.currentTimeMillis();
        if (now - lastHandledAt < MIN_INTERVAL_MS) return;

        // 快速空跑：当前窗口是否像命令方块界面
        AccessibilityNodeInfo probe = getRootInActiveWindow();
        if (probe == null) return;
        boolean looks = looksLikeCommandBlockScreen(probe);
        boolean gameWin = isGameWindow(probe);
        probe.recycle();
        // 部署运行中：切到游戏窗口就尝试（即使 UI 判定不通过，
        // 失败也会复制指令到剪贴板并提示，不再"点了没反应"）
        if (!looks && !gameWin) return;

        lastHandledAt = now;

        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (deploying) return;
                deploying = true;
                try {
                    deployCurrentBlock();
                } finally {
                    deploying = false;
                }
            }
        }, OPEN_DELAY_MS);
    }

    /** 判断当前窗口是否属于《我的世界》（网易版/基岩版） */
    private boolean isGameWindow(AccessibilityNodeInfo root) {
        if (root == null) return false;
        String pkg = root.getPackageName() == null ? "" : root.getPackageName().toString();
        return pkg.contains("netease") || pkg.contains("mojang")
                || pkg.contains("minecraft") || pkg.contains("x19");
    }

    private boolean looksLikeCommandBlockScreen(AccessibilityNodeInfo root) {
        List<String> texts = new ArrayList<>();
        List<AccessibilityNodeInfo> editables = new ArrayList<>();
        List<AccessibilityNodeInfo> buttons = new ArrayList<>();
        collectNodes(root, texts, editables, buttons);
        boolean hasEdit = !editables.isEmpty();
        boolean hasClose = false;
        for (AccessibilityNodeInfo b : buttons) {
            String t = nodeText(b);
            if (t != null && containsAny(t, new String[]{"完成", "确定", "关闭", "保存", "Done", "Confirm"})) {
                hasClose = true;
                break;
            }
        }
        for (AccessibilityNodeInfo e : editables) e.recycle();
        for (AccessibilityNodeInfo b : buttons) b.recycle();

        boolean titleHit = false;
        for (String t : texts) {
            if (t.contains("命令方块") || t.contains("Command Block")) {
                titleHit = true;
                break;
            }
        }
        if (titleHit || (hasEdit && hasClose)) return true;

        // —— 网易版增强通道：自绘 UI 判定 ——
        // 基岩版/网易版命令方块界面是游戏自绘 UI：根节点通常是一个全屏 SurfaceView/TextureView，
        // 或全屏 ViewGroup，无障碍树里没有文本与 EditText。
        // 条件：部署引擎运行中 + 窗口事件是「新窗口弹出」+ 根视图铺满屏幕 → 视为候选。
        CharSequence cls = root.getClassName();
        String cn = cls == null ? "" : cls.toString();
        String pkg = root.getPackageName() == null ? "" : root.getPackageName().toString();
        boolean gamePkg = pkg.contains("netease") || pkg.contains("mojang")
                || pkg.contains("minecraft") || pkg.contains("x19");
        boolean fullscreenSurface = (cn.contains("SurfaceView") || cn.contains("TextureView"))
                || (cn.contains("FrameLayout") || cn.contains("ViewGroup"));
        // 全屏判定：根节点填满屏幕（放宽阈值，兼容更多分辨率）
        android.graphics.Rect r = new android.graphics.Rect();
        root.getBoundsInScreen(r);
        boolean full = r.width() >= 540 && r.height() >= 540;
        if (gamePkg && fullscreenSurface && full) {
            return true;
        }
        return false;
    }

    private void collectNodes(AccessibilityNodeInfo node, List<String> texts,
                              List<AccessibilityNodeInfo> editables,
                              List<AccessibilityNodeInfo> buttons) {
        if (node == null) return;
        String t = nodeText(node);
        if (t != null && !t.isEmpty()) texts.add(t);
        if (isEditableNode(node)) {
            editables.add(node);
        } else if (node.isClickable() && node.getChildCount() <= 1) {
            buttons.add(node);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectNodes(child, texts, editables, buttons);
            }
        }
    }

    /** 多通道输入框识别 */
    private boolean isEditableNode(AccessibilityNodeInfo n) {
        if (n == null) return false;
        CharSequence cls = n.getClassName();
        String cn = cls == null ? "" : cls.toString();
        String cdes = n.getContentDescription() == null ? "" : n.getContentDescription().toString();
        String vid = n.getViewIdResourceName() == null ? "" : n.getViewIdResourceName();
        boolean classHit = cn.contains("EditText") || cn.contains("TextInput")
                || cn.contains("TextField") || cn.contains("TextBox");
        boolean descHit = cdes.contains("输入") || cdes.contains("编辑") || cdes.contains("命令")
                || cdes.contains("command") || cdes.contains("input") || cdes.contains("edit");
        boolean vidHit = vid.contains("input") || vid.contains("edit") || vid.contains("command")
                || vid.contains("text");
        boolean focusHit = n.isFocused() || n.isEditable() || (n.isFocusable() && n.getChildCount() == 0);
        return classHit || descHit || vidHit || focusHit;
    }

    private void deployCurrentBlock() {
        DeployEngine engine = DeployEngine.get();
        String cmd = engine.currentBlock();
        if (cmd == null) {
            engine.markBlockFail("no command");
            return;
        }

        // 每次操作前重新取树，避免旧节点失效
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            engine.markBlockFail("window lost");
            return;
        }

        // 1. 设置模式 / 条件 / 红石（找不到控件时静默跳过，不阻塞主流程）
        configureSetting(root, engine.targetMode());
        configureSetting(root, engine.targetCond());
        configureSetting(root, engine.targetRedstone());

        // 2. 找输入框（重新取树）
        root.recycle();
        AccessibilityNodeInfo input = findEditable();
        if (input == null) {
            // 网易版自绘 UI 兜底：模拟点击屏幕中央偏上，尝试唤起内嵌输入框
            tapFallback();
            sleep(350);
            input = findEditable();
        }
        if (input == null) {
            // 仍失败：复制到剪贴板 + 提示手动粘贴
            copyToClipboard(cmd);
            engine.markBlockFail("未识别输入框：指令已复制，请在命令方块输入框长按粘贴，粘贴后点「重试」");
            return;
        }

        // 3. 填入指令
        boolean ok = fillInput(input, cmd);
        if (ok && engine.isAutoVerify()) {
            String gotStr = nodeText(input);
            if (gotStr == null || !norm(gotStr).equals(norm(cmd))) {
                ok = forceSetText(input, cmd);
                if (ok) {
                    String got2 = nodeText(input);
                    if (got2 == null || !norm(got2).equals(norm(cmd))) {
                        input.recycle();
                        copyToClipboard(cmd);
                        engine.markBlockFail("校验不符：指令已复制，请手动粘贴后点「重试」");
                        return;
                    }
                }
            }
        }
        input.recycle();

        // 4. 点击完成/确定
        AccessibilityNodeInfo root2 = getRootInActiveWindow();
        if (root2 == null) {
            engine.markBlockFail("window lost on close");
            return;
        }
        boolean closed = clickWord(root2, new String[]{"完成", "确定", "关闭", "保存", "Done", "Confirm"});
        root2.recycle();
        if (!closed) {
            engine.markBlockFail("close button not found");
            return;
        }

        engine.markBlockOk();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                lastHandledAt = 0;
            }
        }, 600);
    }

    /** 点击模式/条件/红石：包含匹配 */
    private void configureSetting(AccessibilityNodeInfo root, String target) {
        if (target == null || target.isEmpty()) return;
        AccessibilityNodeInfo n = findNodeByText(root, new String[]{target}, true);
        if (n == null) return;
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        n.recycle();
        sleep(200);
    }

    /** 坐标点击兜底：点屏幕中央偏上，尝试唤起网易版内嵌输入光标 */
    private void tapFallback() {
        if (Build.VERSION.SDK_INT < 24) return;
        try {
            Display display = getDisplay();
            if (display == null) return;
            android.graphics.Point p = new android.graphics.Point();
            display.getSize(p);
            int x = p.x / 2;
            int y = (int) (p.y * 0.45f);
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription.StrokeDescription stroke =
                    new GestureDescription.StrokeDescription(path, 0, 120);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(stroke);
            dispatchGesture(b.build(), null, null);
        } catch (Exception ignored) {
        }
    }

    private AccessibilityNodeInfo findEditable() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        List<AccessibilityNodeInfo> candidates = new ArrayList<>();
        collectEditables(root, candidates);
        root.recycle();
        if (candidates.isEmpty()) return null;
        AccessibilityNodeInfo best = null;
        int bestScore = -1;
        for (AccessibilityNodeInfo e : candidates) {
            int score = 0;
            if (e.isFocused()) score += 10;
            if (e.isEditable()) score += 5;
            String cn = e.getClassName() == null ? "" : e.getClassName().toString();
            if (cn.contains("EditText")) score += 3;
            try {
                if (e.getText() != null && e.getText().length() > 0) score += 1;
            } catch (Exception ignored) {
            }
            if (score > bestScore) {
                if (best != null) best.recycle();
                best = e;
                bestScore = score;
            } else {
                e.recycle();
            }
        }
        return best;
    }

    private void collectEditables(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        if (isEditableNode(node)) out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) collectEditables(child, out);
        }
    }

    private boolean fillInput(AccessibilityNodeInfo input, String cmd) {
        // 1) 先设剪贴板
        copyToClipboard(cmd);
        // 2) FOCUS
        boolean focused = input.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        sleep(150);
        // 3) 若未聚焦，尝试 CLICK
        if (!focused) {
            input.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            sleep(200);
        }
        // 4) PASTE
        if (input.performAction(AccessibilityNodeInfo.ACTION_PASTE)) {
            sleep(250);
            return true;
        }
        // 5) 兜底 SET_TEXT
        return forceSetText(input, cmd);
    }

    private boolean forceSetText(AccessibilityNodeInfo input, String cmd) {
        try {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cmd);
            boolean ok = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            sleep(250);
            return ok;
        } catch (Exception e) {
            return false;
        }
    }

    private void copyToClipboard(String cmd) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("tst_cmd", cmd));
        } catch (Exception ignored) {
        }
    }

    private boolean clickWord(AccessibilityNodeInfo root, String[] words) {
        AccessibilityNodeInfo n = findNodeByText(root, words, true);
        if (n == null) return false;
        boolean ok = n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        n.recycle();
        return ok;
    }

    private AccessibilityNodeInfo findNodeByText(AccessibilityNodeInfo root, String[] words, boolean any) {
        List<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collectByText(root, words, any, nodes);
        if (nodes.isEmpty()) return null;
        AccessibilityNodeInfo best = nodes.get(0);
        for (int i = 1; i < nodes.size(); i++) {
            nodes.get(i).recycle();
        }
        return best;
    }

    private void collectByText(AccessibilityNodeInfo node, String[] words, boolean any,
                               List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        String t = nodeText(node);
        if (t != null && !t.isEmpty()) {
            for (String w : words) {
                boolean hit = any ? t.contains(w) : t.equals(w);
                if (hit) {
                    out.add(node);
                    break;
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) collectByText(child, words, any, out);
        }
    }

    private String nodeText(AccessibilityNodeInfo n) {
        if (n == null) return null;
        CharSequence t = n.getText();
        if (t != null && !t.toString().trim().isEmpty()) return t.toString().trim();
        CharSequence d = n.getContentDescription();
        if (d != null && !d.toString().trim().isEmpty()) return d.toString().trim();
        return null;
    }

    private boolean containsAny(String s, String[] words) {
        if (s == null) return false;
        for (String w : words) {
            if (s.contains(w)) return true;
        }
        return false;
    }

    private String norm(String s) {
        if (s == null) return "";
        return s.replace("\n", "").replace("\r", "").replace(" ", "").trim();
    }

    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
