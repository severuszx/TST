package com.tst.commandtool;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class TaskStore {

    private static final String PREFS = "tst_cmd";
    private static final String KEY_TASKS = "tasks";
    private static final String KEY_SETTINGS = "settings";

    public static String[] defaultWords() {
        return new String[]{"普通,循环,连锁", "无条件,有条件的", "需要红石,不需要红石"};
    }

    public static JSONObject loadSettings(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_SETTINGS, null);
        if (raw == null) {
            JSONObject def = new JSONObject();
            try {
                def.put("blockLimit", CommandSplitter.DEFAULT_LIMIT);
                def.put("modeWords", defaultWords()[0]);
                def.put("condWords", defaultWords()[1]);
                def.put("redstoneWords", defaultWords()[2]);
                def.put("autoVerify", true);
                def.put("targetMode", "循环");
                def.put("targetCond", "无条件");
                def.put("targetRedstone", "需要红石");
            } catch (Exception ignored) {
            }
            return def;
        }
        try {
            return new JSONObject(raw);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static void saveSettings(Context c, JSONObject s) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_SETTINGS, s.toString()).apply();
    }

    public static List<CommandTask> loadTasks(Context c) {
        List<CommandTask> list = new ArrayList<>();
        String raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TASKS, null);
        if (raw == null) return list;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                list.add(CommandTask.fromJson(arr.optJSONObject(i)));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public static void saveTasks(Context c, List<CommandTask> tasks) {
        JSONArray arr = new JSONArray();
        for (CommandTask t : tasks) arr.put(t.toJson());
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_TASKS, arr.toString()).apply();
    }
}
