package com.tst.commandtool;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.Locale;

/**
 * 设置页（PCL2 式，独立页面带顶栏）：
 * 账号/头像昵称（登录收纳于此）、版本号、开源仓库、隐私政策、悬浮窗权限、导入说明。
 */
public class SettingsActivity extends Activity {

    private TextView avatarText, accountName, accountSub, btnAccount, versionValue;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        TopbarNav.attach(this, findViewById(R.id.topbar), "settings");

        avatarText = findViewById(R.id.avatarText);
        accountName = findViewById(R.id.accountName);
        accountSub = findViewById(R.id.accountSub);
        btnAccount = findViewById(R.id.btnAccount);
        versionValue = findViewById(R.id.versionValue);

        versionValue.setText("v" + VersionManager.BuildConfigHolder.VERSION_NAME
                + "（build " + VersionManager.BuildConfigHolder.VERSION_CODE + "）");

        findViewById(R.id.accountCard).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAccountTap();
            }
        });
        btnAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAccountTap();
            }
        });
        findViewById(R.id.rowSource).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBrowser("https://github.com/severuszx/TST");
            }
        });
        findViewById(R.id.rowPrivacy).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TstDialog.show(SettingsActivity.this, "隐私政策",
                        "The Slow Tide 客户端与官网共用一套账号体系。\n\n我们仅收集：邮箱地址（用于登录验证码）、帖子/评论/收藏等你在站内产生的内容。不会收集你的位置、通讯录或设备敏感信息，也不会向第三方出售任何个人数据。\n\n登录状态下，你的昵称、头像、发帖内容会公开展示在官网与客户端内。你可以随时在官网个人中心修改资料或退出登录。\n\n本项目为开源项目，代码公开在 github.com/severuszx/TST。",
                        "知道了", null, null, null);
            }
        });
        findViewById(R.id.rowFloat).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ensureFloat();
            }
        });
        findViewById(R.id.rowHelp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TstDialog.show(SettingsActivity.this, "导入说明",
                        "1. 进游戏后打开聊天栏，把光标对准命令方块\n2. 开启悬浮窗（设置里可再开启权限）\n3. 点击悬浮球「部署」，自动逐块粘贴命令并发送\n\n悬浮球会自动跳过重复的命令方块。",
                        "知道了", null, null, null);
            }
        });

        refreshAccount();
    }

    private void onAccountTap() {
        if (LoginManager.isLoggedIn(this)) {
            TstDialog.show(this, "退出登录",
                    "确定要退出当前官网账号吗？退出后部分功能（积分、个人中心）不可用。",
                    "退出", new TstDialog.Btn() {
                        @Override
                        public void onClick() {
                            LoginManager.logout(SettingsActivity.this);
                            Toast.makeText(SettingsActivity.this, "已退出登录", Toast.LENGTH_SHORT).show();
                            refreshAccount();
                        }
                    }, "取消", null);
        } else {
            showLoginDialog();
        }
    }

    private void refreshAccount() {
        if (LoginManager.isLoggedIn(this)) {
            String email = LoginManager.email(this);
            String name = email == null ? "" : email;
            accountName.setText(name.isEmpty() ? "已登录" : name);
            accountSub.setText(R.string.account_logged_sub);
            btnAccount.setText(R.string.login_logout);
            String ch = name.trim().isEmpty() ? "T" : name.trim().substring(0, 1).toUpperCase(Locale.ROOT);
            avatarText.setText(ch);
        } else {
            accountName.setText(R.string.login_btn);
            accountSub.setText(R.string.account_tap_to_login);
            btnAccount.setText(R.string.login_btn);
            avatarText.setText("T");
        }
    }

    private void showLoginDialog() {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        View v = getLayoutInflater().inflate(R.layout.login_dialog, null);
        dialog.setContentView(v);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_glass_card);
            dialog.getWindow().setDimAmount(0.5f);
        }
        final EditText emailEl = v.findViewById(R.id.loginEmail);
        final EditText codeEl = v.findViewById(R.id.loginCode);
        final Button sendBtn = v.findViewById(R.id.loginSendCode);
        final Button confirmBtn = v.findViewById(R.id.loginConfirm);
        final Button cancelBtn = v.findViewById(R.id.loginCancel);
        final TextView msg = v.findViewById(R.id.loginMsg);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                sendBtn.setEnabled(false);
                sendBtn.setText(R.string.login_sending);
                LoginManager.sendCode(email, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                msg.setVisibility(View.VISIBLE);
                                msg.setText(s);
                                if (ok) {
                                    startCountdown(sendBtn);
                                } else {
                                    sendBtn.setEnabled(true);
                                    sendBtn.setText(R.string.login_send_code);
                                }
                            }
                        });
                    }
                });
            }
        });

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                final String code = codeEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                if (code.length() != 6) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_code);
                    return;
                }
                confirmBtn.setEnabled(false);
                LoginManager.verify(email, code, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                confirmBtn.setEnabled(true);
                                if (ok && data != null) {
                                    LoginManager.save(SettingsActivity.this,
                                            data.optString("token"),
                                            data.optString("email"),
                                            data.optString("uid"));
                                    msg.setText(R.string.login_success);
                                    dialog.dismiss();
                                    Toast.makeText(SettingsActivity.this, R.string.login_success, Toast.LENGTH_SHORT).show();
                                    refreshAccount();
                                    LoginManager.whoami(SettingsActivity.this, null);
                                } else {
                                    msg.setText(getString(R.string.login_failed, s == null ? "" : s));
                                }
                            }
                        });
                    }
                });
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void startCountdown(final Button btn) {
        final int[] left = {60};
        btn.setText(getString(R.string.login_countdown, left[0]));
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                left[0]--;
                if (left[0] <= 0) {
                    btn.setEnabled(true);
                    btn.setText(R.string.login_send_code);
                } else {
                    btn.setText(getString(R.string.login_countdown, left[0]));
                    ui.postDelayed(this, 1000);
                }
            }
        }, 1000);
    }

    private void ensureFloat() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            TstDialog.show(this, "需要悬浮窗权限",
                    "开启悬浮窗后，进游戏会有一个悬浮球，对准命令方块点它即可自动逐块粘贴部署。\n\n现在去系统设置里允许「The Slow Tide」显示在其他应用上层。",
                    "去开启", new TstDialog.Btn() {
                        @Override
                        public void onClick() {
                            try {
                                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:" + getPackageName())));
                            } catch (Exception e) {
                                startActivity(new Intent(Settings.ACTION_SETTINGS));
                            }
                        }
                    }, "稍后", null);
            return;
        }
        startService(new Intent(this, FloatService.class));
        Toast.makeText(this, "悬浮窗已开启，进游戏对准命令方块点击悬浮球开始部署", Toast.LENGTH_SHORT).show();
    }

    private void openBrowser(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "无法打开", Toast.LENGTH_SHORT).show();
        }
    }
}
