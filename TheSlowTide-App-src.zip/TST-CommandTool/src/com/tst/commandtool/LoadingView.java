package com.tst.commandtool;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * PCL2 式加载动画：像素镐子挖掘草方块 + 底部绿色进度条。
 * 镐子随动画循环举起落下，方块下方逐渐出现裂缝，进度条同步推进。
 */
public class LoadingView extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pf = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int progress = 0;
    private float digPhase = 0f; // 0..1 循环，镐子举起落下
    private ValueAnimator digAnim;

    public LoadingView(Context c) {
        this(c, null);
    }

    public LoadingView(Context c, AttributeSet a) {
        super(c, a);
    }

    public void setProgress(int prog) {
        progress = Math.max(0, Math.min(100, prog));
        postInvalidateOnAnimation();
    }

    public void start() {
        if (digAnim != null && digAnim.isRunning()) return;
        final ValueAnimator dig = ValueAnimator.ofFloat(0f, 1f);
        dig.setDuration(900);
        dig.setRepeatCount(ValueAnimator.INFINITE);
        dig.setRepeatMode(ValueAnimator.RESTART);
        dig.setInterpolator(new LinearInterpolator());
        dig.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                digPhase = (Float) a.getAnimatedValue();
                postInvalidateOnAnimation();
            }
        });
        digAnim = dig;
        dig.start();
    }

    public void cancelAnim() {
        if (digAnim != null) {
            digAnim.cancel();
            digAnim = null;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f;
        // 草方块中心约在 0.42h
        float sq = dp(56);
        float sqY = h * 0.40f - sq / 2f;
        RectF top = new RectF(cx - sq / 2f, sqY, cx + sq / 2f, sqY + sq * 0.30f);
        RectF side = new RectF(cx - sq / 2f, sqY + sq * 0.30f, cx + sq / 2f, sqY + sq);
        p.setColor(0xFF7cba5a);
        c.drawRect(top, p);
        p.setColor(0xFF8a5a3b);
        c.drawRect(side, p);
        // 方块黑色描边
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(2));
        p.setColor(0xFF1f2937);
        c.drawRect(top, p);
        c.drawRect(side, p);
        p.setStyle(Paint.Style.FILL);

        // 裂缝随进度加深
        int cracks = progress / 12;
        p.setColor(0xFF1f2937);
        p.setStrokeWidth(dp(2));
        for (int i = 0; i < cracks; i++) {
            float y = sqY + sq * 0.30f + dp(6) + i * dp(7);
            c.drawLine(cx - sq / 2f + dp(6), y, cx + sq / 2f - dp(8), y + dp(4), p);
        }

        // 镐子：随 digPhase 从方块上方落下
        float lift = (float) (Math.sin(digPhase * Math.PI)); // 0..1..0
        float pickX = cx;
        float pickY = sqY - dp(18) + lift * sq * 0.9f;
        float rot = (float) ((0.5f - digPhase) * 40.0f); // 举起时后仰，落下时前倾
        c.save();
        c.translate(pickX, pickY);
        c.rotate(rot);
        // 木柄（斜向左上）
        p.setColor(0xFF6b4a2f);
        p.setStrokeWidth(dp(5));
        p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(0, 0, -dp(34), -dp(26), p);
        // 镐头（右侧两段灰，形成镐形）
        p.setStrokeWidth(dp(6));
        p.setColor(0xFFcbd5e1);
        c.drawLine(0, 0, dp(10), -dp(6), p);
        c.drawLine(0, 0, dp(4), dp(8), p);
        c.drawLine(0, 0, dp(18), dp(0), p);
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setStrokeWidth(0);
        c.restore();

        // 底部 PCL2 式绿色进度条
        float barW = w * 0.62f;
        float barH = dp(7);
        float barX = cx - barW / 2f;
        float barY = h * 0.82f;
        RectF track = new RectF(barX, barY, barX + barW, barY + barH);
        pf.setColor(0xFFe2e8f0);
        c.drawRoundRect(track, barH / 2, barH / 2, pf);
        RectF fill = new RectF(barX, barY, barX + barW * progress / 100f, barY + barH);
        pf.setColor(0xFF4ade80);
        c.drawRoundRect(fill, barH / 2, barH / 2, pf);

        // 进度文字
        pf.setColor(0xFF1f2937);
        pf.setTextSize(dp(13));
        pf.setTextAlign(Paint.Align.CENTER);
        c.drawText(progress + "%", cx, barY - dp(6), pf);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
