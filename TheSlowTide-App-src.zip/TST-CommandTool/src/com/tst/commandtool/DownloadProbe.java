package com.tst.commandtool;

import android.app.DownloadManager;
import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

/**
 * 下载进度追踪：记录本客户端发起的 DownloadManager 任务，
 * 供主页查询实时进度（文件名 / 百分比 / 状态）。
 */
public class DownloadProbe {

    public static class Item {
        public long id;
        public String name;
        public int progress;
        public String status;
    }

    private static final List<Item> cache = new ArrayList<Item>();

    public static synchronized void track(Context c, long id, String url, String fileName) {
        Item it = new Item();
        it.id = id;
        it.name = fileName;
        cache.add(it);
        while (cache.size() > 8) cache.remove(0);
    }

    /** 返回当前活跃下载（下载中/等待/暂停），已完成的任务从缓存移除。 */
    public static synchronized List<Item> active(Context c) {
        DownloadManager dm = (DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE);
        List<Item> out = new ArrayList<Item>();
        if (dm == null) return out;
        for (int i = cache.size() - 1; i >= 0; i--) {
            Item it = cache.get(i);
            DownloadManager.Query q = new DownloadManager.Query();
            q.setFilterById(it.id);
            Cursor cur = null;
            try {
                cur = dm.query(q);
                if (cur != null && cur.moveToFirst()) {
                    int st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    long total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    long done = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    if (st == DownloadManager.STATUS_SUCCESSFUL || st == DownloadManager.STATUS_FAILED) {
                        cache.remove(i);
                        continue;
                    }
                    Item copy = new Item();
                    copy.id = it.id;
                    copy.name = it.name;
                    copy.progress = total > 0 ? (int) (done * 100 / total) : 0;
                    if (st == DownloadManager.STATUS_PENDING) copy.status = "等待中";
                    else if (st == DownloadManager.STATUS_PAUSED) copy.status = "已暂停";
                    else copy.status = "下载中 " + copy.progress + "%";
                    out.add(copy);
                }
            } catch (Exception ignored) {
            } finally {
                if (cur != null) cur.close();
            }
        }
        return out;
    }
}
