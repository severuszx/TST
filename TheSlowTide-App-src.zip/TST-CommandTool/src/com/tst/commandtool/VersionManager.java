package com.tst.commandtool;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * 云端版本管理：从主站拉取 version.json，与本地版本比较。
 * 主站静态文件：https://theslowtide.pages.dev/version.json
 * 格式：{"versionCode":2,"versionName":"1.1.0","url":".../TheSlowTide.apk","note":"更新说明"}
 */
public class VersionManager {

    public static final String VERSION_URL = "https://theslowtide.pages.dev/version.json";

    public interface CheckCallback {
        void onResult(boolean hasNew, JSONObject info, String error);
    }

    public static void check(final Context c, final CheckCallback cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(VERSION_URL).openConnection();
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(12000);
                    conn.setRequestMethod("GET");
                    int code = conn.getResponseCode();
                    InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
                    if (is == null) {
                        cb.onResult(false, null, "版本服务器无响应");
                        return;
                    }
                    BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    conn.disconnect();
                    JSONObject o = new JSONObject(sb.toString());
                    int remoteCode = o.optInt("versionCode", 0);
                    int localCode = BuildConfigHolder.VERSION_CODE;
                    cb.onResult(remoteCode > localCode, o, null);
                } catch (final Exception e) {
                    cb.onResult(false, null, "检查失败：" + e.getMessage());
                }
            }
        }).start();
    }

    /** 打开浏览器下载新版本 */
    public static void openDownload(Context c, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception e) {
            // 无浏览器时兜底
        }
    }

    /** 占位：真实版本号由 build.ps1 从 AndroidManifest.xml 自动注入 */
    public static class BuildConfigHolder {
        public static final int VERSION_CODE = 17;
        public static final String VERSION_NAME = "1.5.2";
    }
}
