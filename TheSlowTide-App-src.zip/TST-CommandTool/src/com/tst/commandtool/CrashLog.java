package com.tst.commandtool;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 崩溃诊断：把运行时异常写入应用外部文件，便于用户反馈时定位。
 * 文件：Android/data/com.tst.commandtool/files/crash.log（无需额外权限）。
 */
public class CrashLog {
    public static void log(Context c, String tag, Throwable t) {
        try {
            File dir = c.getExternalFilesDir(null);
            if (dir == null) dir = c.getFilesDir();
            File f = new File(dir, "crash.log");
            FileOutputStream fos = new FileOutputStream(f, true);
            OutputStreamWriter w = new OutputStreamWriter(fos, "UTF-8");
            String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
            w.write("[" + ts + "] " + tag + "\n");
            if (t != null) {
                w.write(Log.getStackTraceString(t));
                w.write("\n");
            }
            w.flush();
            w.close();
        } catch (Exception ignored) {
        }
    }

    public static void toast(Context c, String msg) {
        try {
            android.widget.Toast.makeText(c, msg, android.widget.Toast.LENGTH_LONG).show();
        } catch (Exception ignored) {
        }
    }
}
