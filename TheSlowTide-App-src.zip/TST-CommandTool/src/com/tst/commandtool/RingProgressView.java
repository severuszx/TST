package com.tst.commandtool;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * PCL2 式大圆圈总进度：背景圆环 + 进度圆环 + 中心百分比。
 */
public class RingProgressView extends View {

    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arc = new RectF();
    private int progress = 0;
    private float stroke;

    public RingProgressView(Context c) {
        this(c, null);
    }

    public RingProgressView(Context c, AttributeSet a) {
        super(c, a);
        stroke = dp(10);
        bg.setColor(0xFFe2e8f0);
        bg.setStyle(Paint.Style.STROKE);
        bg.setStrokeWidth(stroke);
        fg.setColor(0xFF3b82f6);
        fg.setStyle(Paint.Style.STROKE);
        fg.setStrokeWidth(stroke);
        fg.setStrokeCap(Paint.Cap.ROUND);
        txt.setColor(0xFF1f2937);
        txt.setTextSize(dp(30));
        txt.setTextAlign(Paint.Align.CENTER);
    }

    public void setProgress(int p) {
        progress = Math.max(0, Math.min(100, p));
        invalidate();
    }

    public int getProgress() {
        return progress;
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float inset = stroke / 2 + dp(2);
        arc.set(inset, inset, w - inset, h - inset);
        c.drawArc(arc, 0, 360, false, bg);
        c.drawArc(arc, -90, 360f * progress / 100, false, fg);
        float cy = h / 2;
        c.drawText(progress + "%", w / 2, cy - (txt.descent() + txt.ascent()) / 2, txt);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
