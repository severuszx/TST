package com.tst.commandtool;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;

/**
 * 顶栏导航（PCL2 式）：主页 / 百宝箱 / 设置。
 * attach() 绑定点击跳转、当前页高亮（白字加粗）、页面切换动画。
 */
public class TopbarNav {

    /** current: "home" / "toybox" / "settings" / "feature"（功能页归属百宝箱） */
    public static void attach(final Activity act, View topbar, final String current) {
        if (topbar == null) return;
        TextView home = topbar.findViewById(R.id.navHome);
        TextView toybox = topbar.findViewById(R.id.navToyBox);
        TextView settings = topbar.findViewById(R.id.navSettings);
        if (home == null || toybox == null || settings == null) return;

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(act, MainActivity.class);
                it.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                act.startActivity(it);
                act.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
        toybox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(act, ToyBoxActivity.class);
                act.startActivity(it);
                act.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(act, SettingsActivity.class);
                act.startActivity(it);
                act.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        TextView target = null;
        if ("home".equals(current)) target = home;
        else if ("toybox".equals(current) || "feature".equals(current)) target = toybox;
        else if ("settings".equals(current)) target = settings;
        if (target != null) {
            target.setTextColor(0xFFFFFFFF);
            target.setTypeface(target.getTypeface(), 1);
        }
    }
}
