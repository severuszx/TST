package com.tst.commandtool;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * 统一功能页外壳：顶部栏(返回/标题/?帮助) + 内容。
 * 内容 = assets 内 HTML 功能页（WebView），所有链接/下载均在软件内部处理，不跳系统浏览器。
 */
public class FeatureActivity extends Activity {

    public static final String EXTRA_FEATURE = "feature";
    private static final String SITE_URL = "https://theslowtide.pages.dev/";
    private static final int REQ_FILE = 2001;

    private TextView featTitle;
    private FrameLayout featContent;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String featureKey;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feature_shell);

        featTitle = findViewById(R.id.featTitle);
        featContent = findViewById(R.id.featContent);
        featureKey = getIntent().getStringExtra(EXTRA_FEATURE);
        if (featureKey == null) featureKey = "tools";

        findViewById(R.id.featBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.featHelp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHelp();
            }
        });

        setupTitle();
        loadFeature();
    }

    private void setupTitle() {
        int titleRes = R.string.feat_tools_title;
        if (featureKey.equals("lib")) titleRes = R.string.feat_lib_title;
        else if (featureKey.equals("site")) titleRes = R.string.feat_site_title;
        else if (featureKey.equals("notice")) titleRes = R.string.feat_notice_title;
        else if (featureKey.equals("selector")) titleRes = R.string.feat_selector_title;
        else if (featureKey.equals("base64")) titleRes = R.string.feat_base64_title;
        else if (featureKey.equals("jsonview")) titleRes = R.string.feat_json_title;
        else if (featureKey.equals("snowball")) titleRes = R.string.feat_snowball_title;
        else if (featureKey.equals("mcdownload")) titleRes = R.string.feat_mc_title;
        else if (featureKey.equals("sites")) titleRes = R.string.feat_sites_title;
        else if (featureKey.equals("skin")) titleRes = R.string.feat_skin_title;
        else if (featureKey.equals("seed")) titleRes = R.string.feat_seed_title;
        featTitle.setText(titleRes);
    }

    private void showHelp() {
        int msgRes = R.string.feat_help_tools;
        if (featureKey.equals("lib")) msgRes = R.string.feat_help_lib;
        else if (featureKey.equals("site")) msgRes = R.string.feat_help_site;
        else if (featureKey.equals("notice")) msgRes = R.string.feat_help_notice;
        else if (featureKey.equals("selector")) msgRes = R.string.feat_help_selector;
        else if (featureKey.equals("base64")) msgRes = R.string.feat_help_base64;
        else if (featureKey.equals("jsonview")) msgRes = R.string.feat_help_json;
        else if (featureKey.equals("snowball")) msgRes = R.string.feat_help_snowball;
        else if (featureKey.equals("mcdownload")) msgRes = R.string.feat_help_mc;
        else if (featureKey.equals("sites")) msgRes = R.string.feat_help_sites;
        else if (featureKey.equals("skin")) msgRes = R.string.feat_help_skin;
        else if (featureKey.equals("seed")) msgRes = R.string.feat_help_seed;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle(featTitle.getText());
        b.setMessage(msgRes);
        b.setNegativeButton("关闭", null);
        b.show();
    }

    private void loadFeature() {
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        webView.setBackgroundColor(0xFFf3f5f8);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePath, WebChromeClient.FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePath;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(FeatureActivity.this, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (featureKey.equals("site")) injectLoginState();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("file://")) {
                    // 全部在软件内部打开，不跳系统浏览器
                    view.loadUrl(url);
                    return true;
                }
                return false;
            }
        });
        // 下载一律走系统下载管理器（软件内完成，不打开系统浏览器）
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                startInternalDownload(url);
            }
        });
        webView.addJavascriptInterface(new TstJs(), "Tst");

        featContent.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        if (featureKey.equals("site")) {
            webView.loadUrl(SITE_URL);
        } else {
            webView.loadUrl("file:///android_asset/features/" + featureKey + ".html");
        }
    }

    private void injectLoginState() {
        if (webView == null || !LoginManager.isLoggedIn(this)) return;
        String token = LoginManager.token(this);
        String email = LoginManager.email(this);
        String uid = LoginManager.uid(this);
        if (token == null) return;
        final String js = "try{"
                + "localStorage.setItem('tst_token','" + jsEsc(token) + "');"
                + "localStorage.setItem('tst_email','" + jsEsc(email == null ? "" : email) + "');"
                + "localStorage.setItem('tst_uid','" + jsEsc(uid == null ? "" : uid) + "');"
                + "}catch(e){}";
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript(js, null);
            }
        });
    }

    private String jsEsc(String s) {
        return s.replace("\\", "\\\\").replace("'", "\\'");
    }

    private void startInternalDownload(String url) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setAllowedOverMetered(true);
            req.setAllowedOverRoaming(true);
            String fileName = "TST_" + System.currentTimeMillis() + "." + guessExt(url);
            // Android 10+ 分区存储：写应用专属外部目录无需权限，确保下载必定成功；
            // 低版本写公共 Downloads 目录。
            if (Build.VERSION.SDK_INT >= 29) {
                req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, fileName);
            } else {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            }
            long id = dm.enqueue(req);
            DownloadProbe.track(this, id, url, fileName);
            Toast.makeText(this, "已开始下载（进度见主页）", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "下载失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private String guessExt(String url) {
        String path = Uri.parse(url).getPath();
        if (path != null) {
            String ext = path.substring(path.lastIndexOf('.') + 1);
            if (ext.length() <= 5 && ext.matches("[a-zA-Z0-9]+")) return ext;
        }
        return "bin";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
                try {
                    getContentResolver().takePersistableUriPermission(data.getData(),
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            featContent.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    // ===== JS 桥：功能页调用 =====

    private class TstJs {
        @android.webkit.JavascriptInterface
        public void copy(final String text) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("tst", text));
                        Toast.makeText(FeatureActivity.this, "已复制到剪贴板", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(FeatureActivity.this, "复制失败", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void toast(final String text) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(FeatureActivity.this, text, Toast.LENGTH_SHORT).show();
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void download(String url) {
            startInternalDownload(url);
        }

        @android.webkit.JavascriptInterface
        public void openWeb(final String url) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (webView != null) webView.loadUrl(url);
                }
            });
        }

        // 跳转到另一个功能页（终端联动用：种子/皮肤/MC 下载等）
        @android.webkit.JavascriptInterface
        public void openFeature(final String key) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(FeatureActivity.this, FeatureActivity.class);
                        i.putExtra(EXTRA_FEATURE, key);
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        // 同步拉取文本（CORS 代理），供皮肤查询等使用
        @android.webkit.JavascriptInterface
        public String httpGet(final String url) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 TST-Client");
                String tok = LoginManager.token(FeatureActivity.this);
                if (tok != null && !tok.isEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer " + tok);
                }
                int code = conn.getResponseCode();
                if (code != 200) return "{\"error\":\"HTTP " + code + "\"}";
                InputStream is = conn.getInputStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
                r.close();
                conn.disconnect();
                return sb.toString();
            } catch (Exception e) {
                return "{\"error\":\"" + (e.getMessage() == null ? "net" : e.getMessage()) + "\"}";
            }
        }

        // 同步 POST（JSON），供种子上报等使用；带登录 token
        @android.webkit.JavascriptInterface
        public String post(final String url, final String body) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 TST-Client");
                String tok = LoginManager.token(FeatureActivity.this);
                if (tok != null && !tok.isEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer " + tok);
                }
                java.io.OutputStream os = conn.getOutputStream();
                os.write(body.getBytes("UTF-8"));
                os.close();
                int code = conn.getResponseCode();
                InputStream is = (code == 200 || code == 201) ? conn.getInputStream() : conn.getErrorStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
                r.close();
                conn.disconnect();
                return sb.toString();
            } catch (Exception e) {
                return "{\"error\":\"" + (e.getMessage() == null ? "net" : e.getMessage()) + "\"}";
            }
        }

        @android.webkit.JavascriptInterface
        public String isLoggedIn() {
            return LoginManager.isLoggedIn(FeatureActivity.this) ? "1" : "0";
        }

        @android.webkit.JavascriptInterface
        public String loginEmail() {
            return LoginManager.email(FeatureActivity.this) == null ? "" : LoginManager.email(FeatureActivity.this);
        }

        @android.webkit.JavascriptInterface
        public String versionName() {
            return VersionManager.BuildConfigHolder.VERSION_NAME;
        }

        @android.webkit.JavascriptInterface
        public String getClip() {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm.hasPrimaryClip()) {
                    CharSequence t = cm.getPrimaryClip().getItemAt(0).getText();
                    return t == null ? "" : t.toString();
                }
            } catch (Exception ignored) {
            }
            return "";
        }

        // 指令部署：保存设置 + 拆分 + 建立任务（实际自动输入由悬浮窗/无障碍完成）
        @android.webkit.JavascriptInterface
        public void startDeploy(final String raw, final int limit,
                                final String modeWords, final String condWords, final String redstoneWords) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        int lim = limit > 0 ? limit : CommandSplitter.DEFAULT_LIMIT;
                        JSONObject s = TaskStore.loadSettings(FeatureActivity.this);
                        s.put("blockLimit", lim);
                        if (modeWords != null && !modeWords.trim().isEmpty()) s.put("modeWords", modeWords.trim());
                        if (condWords != null && !condWords.trim().isEmpty()) s.put("condWords", condWords.trim());
                        if (redstoneWords != null && !redstoneWords.trim().isEmpty()) s.put("redstoneWords", redstoneWords.trim());
                        s.put("targetMode", firstWord(modeWords));
                        s.put("targetCond", firstWord(condWords));
                        s.put("targetRedstone", firstWord(redstoneWords));
                        s.put("autoVerify", true);
                        TaskStore.saveSettings(FeatureActivity.this, s);
                        DeployEngine.get().attach(FeatureActivity.this);

                        List<String> blocks = CommandSplitter.split(raw, lim);
                        if (blocks == null || blocks.isEmpty()) {
                            Toast.makeText(FeatureActivity.this, "没有可部署的指令块", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        CommandTask t = new CommandTask();
                        t.name = "部署任务";
                        t.blocks.addAll(blocks);
                        List<CommandTask> tasks = TaskStore.loadTasks(FeatureActivity.this);
                        tasks.add(t);
                        TaskStore.saveTasks(FeatureActivity.this, tasks);
                        DeployEngine.get().setTask(t);
                        DeployEngine.get().start();
                        ensureFloat();
                        Toast.makeText(FeatureActivity.this,
                                "已生成 " + blocks.size() + " 块，请开启悬浮窗+无障碍后进游戏点开命令方块自动部署",
                                Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Toast.makeText(FeatureActivity.this, "部署失败：" + (e.getMessage() == null ? "" : e.getMessage()), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public String floatState() {
            return FloatService.running ? "on" : "off";
        }

        @android.webkit.JavascriptInterface
        public String accessState() {
            try {
                android.view.accessibility.AccessibilityManager am =
                        (android.view.accessibility.AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
                List<AccessibilityServiceInfo> list =
                        am.getEnabledAccessibilityServiceList(
                                AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
                for (AccessibilityServiceInfo info : list) {
                    if (info.getResolveInfo().serviceInfo.packageName.equals(getPackageName())) return "on";
                }
            } catch (Exception ignored) {
            }
            return "off";
        }

        @android.webkit.JavascriptInterface
        public void toggleFloat() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(FeatureActivity.this)) {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:" + getPackageName())));
                        } catch (Exception e) {
                            startActivity(new Intent(Settings.ACTION_SETTINGS));
                        }
                        return;
                    }
                    if (FloatService.running) {
                        stopService(new Intent(FeatureActivity.this, FloatService.class));
                    } else {
                        startService(new Intent(FeatureActivity.this, FloatService.class));
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void openFloatPerm() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void openAccessPerm() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    }
                }
            });
        }

        private String firstWord(String s) {
            if (s == null) return "";
            String[] parts = s.split(",");
            return parts.length > 0 ? parts[0].trim() : "";
        }

        private void ensureFloat() {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(FeatureActivity.this)) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) {
                }
                return;
            }
            startService(new Intent(FeatureActivity.this, FloatService.class));
        }
    }
}
