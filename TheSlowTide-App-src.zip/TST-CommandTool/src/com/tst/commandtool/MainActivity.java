package com.tst.commandtool;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 主页（PCL2 式）：账号卡（头像+昵称）+ 大启动按钮（开启悬浮窗导入）
 * + 时钟 + 下载进度 + 百宝箱入口 + 公告 + 底部版本信息。
 */
public class MainActivity extends Activity {

    private static final String NOTICES_URL = "https://theslowtide.pages.dev/announcements.json";

    private TextView accountName, accountSub, avatarText, launchSub, clock, meVersion;
    private TextView noticeTitle, noticeBrief;
    private TextView btnLogin;
    private LinearLayout downloadBox;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private boolean ticking = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_main);
            DeployEngine.get().attach(this);
            initViews();
        } catch (Throwable t) {
            // 任何启动异常：记录日志并显示，不让应用直接闪退
            CrashLog.log(this, "MainActivity.onCreate", t);
            CrashLog.toast(this, "启动遇到问题：" + t.getMessage() + "\n详情已写入崩溃日志");
            finish();
            return;
        }
        try {
            loadNotices();
            checkUpdateSilent();
        } catch (Throwable ignored) {
        }
    }

    private void initViews() {
        accountName = findViewById(R.id.accountName);
        accountSub = findViewById(R.id.accountSub);
        avatarText = findViewById(R.id.avatarText);
        btnLogin = findViewById(R.id.btnLogin);
        launchSub = findViewById(R.id.launchSub);
        clock = findViewById(R.id.clock);
        downloadBox = findViewById(R.id.downloadBox);
        noticeTitle = findViewById(R.id.noticeTitle);
        noticeBrief = findViewById(R.id.noticeBrief);
        meVersion = findViewById(R.id.meVersion);

        findViewById(R.id.btnLaunch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ensureFloat();
                } catch (Throwable t) {
                    CrashLog.log(MainActivity.this, "btnLaunch", t);
                }
            }
        });
        findViewById(R.id.btnCheck).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, R.string.update_checking, Toast.LENGTH_SHORT).show();
                checkUpdateSilent();
            }
        });
        // 左侧导航
        findViewById(R.id.sbToyBox).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ToyBoxActivity.class));
            }
        });
        findViewById(R.id.sbWeb).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBrowser("https://theslowtide.pages.dev/");
            }
        });
        findViewById(R.id.sbShop).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBrowser("https://theslowtide.pages.dev/shop.html");
            }
        });
        findViewById(R.id.sbSettings).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettingsDialog();
            }
        });
        findViewById(R.id.noticeCard).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFeature("notice");
            }
        });

        meVersion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBrowser("https://github.com/severuszx/TST");
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (LoginManager.isLoggedIn(MainActivity.this)) {
                    TstDialog.show(MainActivity.this, "退出登录",
                            "确定要退出当前官网账号吗？退出后部分功能（积分、个人中心）不可用。",
                            "退出", new TstDialog.Btn() {
                                @Override
                                public void onClick() {
                                    LoginManager.logout(MainActivity.this);
                                    Toast.makeText(MainActivity.this, "已退出登录", Toast.LENGTH_SHORT).show();
                                    refreshLoginUi();
                                }
                            }, "取消", null);
                } else {
                    showLoginDialog();
                }
            }
        });

        meVersion.setText("v" + VersionManager.BuildConfigHolder.VERSION_NAME + " · 开源 github.com/severuszx/TST");
        refreshLoginUi();
        cardIn(findViewById(R.id.btnLaunch), 40);
        cardIn(findViewById(R.id.noticeCard), 120);
    }

    // ===== PCL2 式卡片进场动画（缩放+上滑+回弹）=====
    private void cardIn(View v, int delay) {
        if (Build.VERSION.SDK_INT < 21) return;
        v.setAlpha(0f);
        v.setScaleX(0.92f);
        v.setScaleY(0.92f);
        v.setTranslationY(24f);
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(320).setStartDelay(delay)
                .setInterpolator(new OvershootInterpolator(1.1f)).start();
    }

    private void openFeature(String key) {
        Intent i = new Intent(this, FeatureActivity.class);
        i.putExtra(FeatureActivity.EXTRA_FEATURE, key);
        startActivity(i);
    }

    private void openBrowser(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "无法打开", Toast.LENGTH_SHORT).show();
        }
    }

    // ===== 账号卡 =====

    private void refreshLoginUi() {
        if (LoginManager.isLoggedIn(this)) {
            String email = LoginManager.email(this);
            String name = email == null ? "" : email;
            accountName.setText(name.isEmpty() ? "已登录" : name);
            accountSub.setText(R.string.account_logged_sub);
            btnLogin.setText(R.string.login_logout);
            String ch = name.trim().isEmpty() ? "T" : name.trim().substring(0, 1).toUpperCase(Locale.ROOT);
            avatarText.setText(ch);
        } else {
            accountName.setText(R.string.login_btn);
            accountSub.setText(R.string.account_tap_to_login);
            btnLogin.setText(R.string.login_btn);
            avatarText.setText("T");
        }
    }

    private void showLoginDialog() {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        View v = getLayoutInflater().inflate(R.layout.login_dialog, null);
        dialog.setContentView(v);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_glass_card);
            dialog.getWindow().setDimAmount(0.5f);
        }
        final EditText emailEl = v.findViewById(R.id.loginEmail);
        final EditText codeEl = v.findViewById(R.id.loginCode);
        final Button sendBtn = v.findViewById(R.id.loginSendCode);
        final Button confirmBtn = v.findViewById(R.id.loginConfirm);
        final Button cancelBtn = v.findViewById(R.id.loginCancel);
        final TextView msg = v.findViewById(R.id.loginMsg);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                sendBtn.setEnabled(false);
                sendBtn.setText(R.string.login_sending);
                LoginManager.sendCode(email, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                msg.setVisibility(View.VISIBLE);
                                msg.setText(s);
                                if (ok) {
                                    startCountdown(sendBtn);
                                } else {
                                    sendBtn.setEnabled(true);
                                    sendBtn.setText(R.string.login_send_code);
                                }
                            }
                        });
                    }
                });
            }
        });

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                final String code = codeEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                if (code.length() != 6) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_code);
                    return;
                }
                confirmBtn.setEnabled(false);
                LoginManager.verify(email, code, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                confirmBtn.setEnabled(true);
                                if (ok && data != null) {
                                    LoginManager.save(MainActivity.this,
                                            data.optString("token"),
                                            data.optString("email"),
                                            data.optString("uid"));
                                    msg.setText(R.string.login_success);
                                    dialog.dismiss();
                                    Toast.makeText(MainActivity.this, R.string.login_success, Toast.LENGTH_SHORT).show();
                                    refreshLoginUi();
                                    LoginManager.whoami(MainActivity.this, null);
                                } else {
                                    msg.setText(getString(R.string.login_failed, s == null ? "" : s));
                                }
                            }
                        });
                    }
                });
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void startCountdown(final Button btn) {
        final int[] left = {60};
        btn.setText(getString(R.string.login_countdown, left[0]));
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                left[0]--;
                if (left[0] <= 0) {
                    btn.setEnabled(true);
                    btn.setText(R.string.login_send_code);
                } else {
                    btn.setText(getString(R.string.login_countdown, left[0]));
                    ui.postDelayed(this, 1000);
                }
            }
        }, 1000);
    }

    // ===== 大启动按钮：开启悬浮窗导入 =====

    private void ensureFloat() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            TstDialog.show(this, "需要悬浮窗权限",
                    "开启悬浮窗后，进游戏会有一个悬浮球，对准命令方块点它即可自动逐块粘贴部署。\n\n现在去系统设置里允许「The Slow Tide」显示在其他应用上层。",
                    "去开启", new TstDialog.Btn() {
                        @Override
                        public void onClick() {
                            try {
                                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:" + getPackageName())));
                            } catch (Exception e) {
                                startActivity(new Intent(Settings.ACTION_SETTINGS));
                            }
                        }
                    }, "稍后", null);
            return;
        }
        startService(new Intent(this, FloatService.class));
        Toast.makeText(this, "悬浮窗已开启，进游戏对准命令方块点击悬浮球开始部署", Toast.LENGTH_SHORT).show();
    }

    private boolean accessibilityOn() {
        try {
            String enabled = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return enabled != null && enabled.contains(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    // ===== 时钟 + 下载进度 =====

    private void startTicker() {
        if (ticking) return;
        ticking = true;
        ticker.post(runTicker);
    }

    private void stopTicker() {
        ticking = false;
        ticker.removeCallbacks(runTicker);
    }

    private final Runnable runTicker = new Runnable() {
        @Override
        public void run() {
            if (!ticking) return;
            try {
                String t = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss", Locale.CHINA).format(new Date());
                clock.setText(t);
                updateLaunchSub();
                refreshDownloads();
            } catch (Throwable ignored) {
            }
            ticker.postDelayed(this, 1000);
        }
    };

    private void updateLaunchSub() {
        boolean f = Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this);
        boolean a = accessibilityOn();
        if (f && a) launchSub.setText("悬浮窗已就绪 · 无障碍已开启 · 进游戏对准命令方块");
        else if (f) launchSub.setText("悬浮窗已就绪 · 无障碍未开启（点击悬浮球仍可手动部署）");
        else launchSub.setText(R.string.launch_btn_sub);
    }

    private void refreshDownloads() {
        List<DownloadProbe.Item> items = DownloadProbe.active(this);
        downloadBox.removeAllViews();
        if (items.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(R.string.home_downloads_empty);
            empty.setTextColor(0xFF5b6675);
            empty.setTextSize(12f);
            empty.setPadding(0, 8, 0, 8);
            downloadBox.addView(empty);
            return;
        }
        for (DownloadProbe.Item it : items) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_btn_ghost);
            card.setPadding(14, 10, 14, 10);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = 8;
            card.setLayoutParams(lp);

            TextView name = new TextView(this);
            name.setText(it.name);
            name.setTextColor(0xFF1f2937);
            name.setTextSize(12.5f);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            card.addView(name);

            ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(100);
            bar.setProgress(it.progress);
            bar.setProgressDrawable(getResources().getDrawable(R.drawable.progress_bar));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
            blp.topMargin = dp(6);
            bar.setLayoutParams(blp);
            card.addView(bar);

            TextView st = new TextView(this);
            st.setText(it.status);
            st.setTextColor(0xFF5b6675);
            st.setTextSize(11f);
            st.setPadding(0, dp(3), 0, 0);
            card.addView(st);

            downloadBox.addView(card);
        }
    }

    // ===== 公告 =====

    private void loadNotices() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection)
                            new java.net.URL(NOTICES_URL).openConnection();
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(12000);
                    conn.setRequestMethod("GET");
                    int code = conn.getResponseCode();
                    if (code != 200) return;
                    InputStream is = conn.getInputStream();
                    BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    conn.disconnect();
                    final JSONArray arr = new JSONObject(sb.toString()).optJSONArray("items");
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            renderTopNotice(arr);
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    private void renderTopNotice(JSONArray arr) {
        if (arr == null || arr.length() == 0) return;
        JSONObject n = arr.optJSONObject(0);
        if (n == null) return;
        String title = n.optString("title", "");
        String date = n.optString("date", "");
        String body = n.optString("body", "");
        noticeTitle.setText((date.isEmpty() ? "" : date + "  ") + title);
        noticeBrief.setText(body);
    }

    // ===== 设置弹窗（版本 / 关于 / 开源 / 检查更新）=====

    private void showSettingsDialog() {
        String body = getString(R.string.me_about_body) + "\n\n当前版本 v" + VersionManager.BuildConfigHolder.VERSION_NAME;
        TstDialog.show(this, "设置", body, "检查更新", new TstDialog.Btn() {
            @Override
            public void onClick() {
                Toast.makeText(MainActivity.this, R.string.update_checking, Toast.LENGTH_SHORT).show();
                checkUpdateSilent();
            }
        }, "开源仓库", new TstDialog.Btn() {
            @Override
            public void onClick() {
                openBrowser("https://github.com/severuszx/TST");
            }
        });
    }

    // ===== 云端版本检查（自绘弹窗）=====

    private void checkUpdateSilent() {
        VersionManager.check(this, new VersionManager.CheckCallback() {
            @Override
            public void onResult(final boolean hasNew, final JSONObject info, String error) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!hasNew) {
                            Toast.makeText(MainActivity.this, "已是最新版本 v" + VersionManager.BuildConfigHolder.VERSION_NAME, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        String note = info.optString("note", "");
                        final String ver = info.optString("versionName", "");
                        final String url = info.optString("url", "");
                        TstDialog.show(MainActivity.this, "发现新版本 v" + ver,
                                note + "\n\n下载安装包将直接在软件内进行，进度见主页「下载」。",
                                "去下载", new TstDialog.Btn() {
                                    @Override
                                    public void onClick() {
                                        VersionManager.openDownload(MainActivity.this, url);
                                    }
                                }, "稍后", null);
                    }
                });
            }
        });
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshLoginUi();
        updateLaunchSub();
        startTicker();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopTicker();
    }

    @Override
    protected void onDestroy() {
        stopTicker();
        super.onDestroy();
    }
}
