package com.tst.commandtool;

import android.app.Activity;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * TST 客户端宿主（PCL2 式单窗口）：
 * 顶部导航栏固定不动，点击只切换顶栏下方的内容区，页面不跳转。
 * 面板：主页 / 百宝箱 / 设置 / 功能页（含终端、隐私政策）。
 */
public class MainActivity extends Activity {

    private static final String NOTICES_URL = "https://theslowtide.pages.dev/announcements.json";
    private static final String SITE_URL = "https://theslowtide.pages.dev/";
    private static final int REQ_FILE = 2001;
    private static final String[][] FEATURES = {
            {"tools", "指令工具", "指令拆分 · 自动部署"},
            {"lib", "指令库", "云端指令模板"},
            {"selector", "选区助手", "坐标选择器"},
            {"base64", "Base64 互译", "图片 · 文本互转"},
            {"jsonview", "JSON 显示", "文本组件 · T 显"},
            {"snowball", "雪球菜单", "T 显生成"},
            {"mcdownload", "MC 下载", "版本下载 · PCL2 启动器"},
            {"skin", "皮肤查询", "正版 ID 查询 · 3D 预览"},
            {"seed", "种子查找", "遗迹 · 结构"},
            {"notice", "公告", "版本更新说明"},
    };

    // 宿主
    private FrameLayout content;
    private LinearLayout topbar;
    private TextView navHome, navToyBox, navSettings;
    private View currentPanel;

    // 主页面板
    private View homeView;
    private TextView accountName, accountSub, avatarText, btnLogin, launchSub, clock, meVersion;
    private TextView noticeTitle, noticeBrief;
    private LinearLayout downloadBox;

    // 设置面板
    private View settingsView;
    private TextView sAvatar, sName, sSub, sBtnAccount, sVersionValue;

    // 功能页
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String featureKey;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private boolean ticking = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_main);
            content = findViewById(R.id.content);
            topbar = findViewById(R.id.topbar);
            navHome = findViewById(R.id.navHome);
            navToyBox = findViewById(R.id.navToyBox);
            navSettings = findViewById(R.id.navSettings);
            DeployEngine.get().attach(this);
            bindTopbar();
            showHome();
        } catch (Throwable t) {
            CrashLog.log(this, "MainActivity.onCreate", t);
            CrashLog.toast(this, "启动遇到问题：" + t.getMessage() + "\n详情已写入崩溃日志");
            finish();
            return;
        }
        try {
            loadNotices();
            checkUpdateSilent();
        } catch (Throwable ignored) {
        }
    }

    // ===== 顶栏 + 面板切换 =====

    private void bindTopbar() {
        navHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHome();
            }
        });
        navToyBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToyBox();
            }
        });
        navSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
    }

    private void highlight(String tab) {
        setTab(navHome, "home".equals(tab));
        setTab(navToyBox, "toybox".equals(tab) || "feature".equals(tab));
        setTab(navSettings, "settings".equals(tab));
    }

    private void setTab(TextView tv, boolean active) {
        if (active) {
            tv.setTextColor(0xFFFFFFFF);
            tv.setTypeface(tv.getTypeface(), 1);
        } else {
            tv.setTextColor(0xFFcbd5e1);
            tv.setTypeface(tv.getTypeface(), 0);
        }
    }

    private void showPanel(final View v) {
        currentPanel = v;
        content.removeAllViews();
        content.addView(v, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        // 干净地直接替换（PCL2 式，极轻淡入，不做花哨动画）
        v.setAlpha(0f);
        v.animate().alpha(1f).setDuration(130).start();
    }

    private void showHome() {
        if (homeView == null) {
            homeView = getLayoutInflater().inflate(R.layout.activity_home, content, false);
            initHome();
        }
        showPanel(homeView);
        highlight("home");
        setTopbarRight(true, null);
        if (ticking) {
            startTicker();
        }
    }

    private void showToyBox() {
        View tb = buildToyBox();
        showPanel(tb);
        highlight("toybox");
        setTopbarRight(false, null);
    }

    private void showSettings() {
        if (settingsView == null) {
            settingsView = getLayoutInflater().inflate(R.layout.activity_settings_panel, content, false);
            initSettings();
        } else {
            refreshAccount();
        }
        showPanel(settingsView);
        highlight("settings");
        setTopbarRight(false, null);
    }

    private void showFeature(String key) {
        featureKey = key;
        if (webView == null) {
            webView = createWebView();
        }
        // 终端页例外：顶栏隐藏、内容全屏；其余功能页显示顶栏。
        boolean terminal = "terminal".equals(key);
        topbar.setVisibility(terminal ? View.GONE : View.VISIBLE);
        showPanel(webView);
        highlight("feature");
        setTopbarRight(!terminal && !"privacy".equals(key), key);
        if ("site".equals(key)) {
            webView.loadUrl(SITE_URL);
        } else {
            webView.loadUrl("file:///android_asset/features/" + key + ".html");
        }
    }

    /** 顶栏右侧按钮位：主页放「检查更新」，功能页放「?」，其余为空。 */
    private void setTopbarRight(boolean show, String key) {
        FrameLayout right = findViewById(R.id.topbarRight);
        right.removeAllViews();
        if (!show) return;
        final TextView btn = new TextView(this);
        if (key == null) {
            // 主页：检查更新
            btn.setText(R.string.me_check_update);
            btn.setTextSize(12f);
            btn.setTextColor(0xFFFFFFFF);
            btn.setBackgroundResource(R.drawable.bg_btn_topbar);
            btn.setPadding(dp(12), dp(6), dp(12), dp(6));
            btn.setGravity(Gravity.CENTER);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(MainActivity.this, R.string.update_checking, Toast.LENGTH_SHORT).show();
                    checkUpdateSilent();
                }
            });
        } else {
            // 功能页：问号帮助
            btn.setText("?");
            btn.setTextSize(14f);
            btn.setGravity(Gravity.CENTER);
            btn.setBackgroundResource(R.drawable.bg_help_dot);
            btn.setTextColor(0xFFFFFFFF);
            final String k = key;
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showFeatureHelp(k);
                }
            });
            btn.setLayoutParams(new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER_VERTICAL));
        }
        right.addView(btn);
    }

    private void showFeatureHelp(String key) {
        int msgRes = R.string.feat_help_tools;
        if (key.equals("lib")) msgRes = R.string.feat_help_lib;
        else if (key.equals("site")) msgRes = R.string.feat_help_site;
        else if (key.equals("notice")) msgRes = R.string.feat_help_notice;
        else if (key.equals("selector")) msgRes = R.string.feat_help_selector;
        else if (key.equals("base64")) msgRes = R.string.feat_help_base64;
        else if (key.equals("jsonview")) msgRes = R.string.feat_help_json;
        else if (key.equals("snowball")) msgRes = R.string.feat_help_snowball;
        else if (key.equals("mcdownload")) msgRes = R.string.feat_help_mc;
        else if (key.equals("sites")) msgRes = R.string.feat_help_sites;
        else if (key.equals("skin")) msgRes = R.string.feat_help_skin;
        else if (key.equals("seed")) msgRes = R.string.feat_help_seed;
        TstDialog.show(this, getString(titleFor(key)), getString(msgRes), "关闭", null, null, null);
    }

    private int titleFor(String key) {
        int res = R.string.feat_tools_title;
        if (key.equals("lib")) res = R.string.feat_lib_title;
        else if (key.equals("site")) res = R.string.feat_site_title;
        else if (key.equals("notice")) res = R.string.feat_notice_title;
        else if (key.equals("selector")) res = R.string.feat_selector_title;
        else if (key.equals("base64")) res = R.string.feat_base64_title;
        else if (key.equals("jsonview")) res = R.string.feat_json_title;
        else if (key.equals("snowball")) res = R.string.feat_snowball_title;
        else if (key.equals("mcdownload")) res = R.string.feat_mc_title;
        else if (key.equals("sites")) res = R.string.feat_sites_title;
        else if (key.equals("skin")) res = R.string.feat_skin_title;
        else if (key.equals("seed")) res = R.string.feat_seed_title;
        else if (key.equals("terminal")) res = R.string.feat_terminal_title;
        else if (key.equals("privacy")) res = R.string.set_privacy;
        return res;
    }

    // ===== 主页面板 =====

    private void initHome() {
        accountName = homeView.findViewById(R.id.accountName);
        accountSub = homeView.findViewById(R.id.accountSub);
        avatarText = homeView.findViewById(R.id.avatarText);
        btnLogin = homeView.findViewById(R.id.btnLogin);
        launchSub = homeView.findViewById(R.id.launchSub);
        clock = homeView.findViewById(R.id.clock);
        downloadBox = homeView.findViewById(R.id.downloadBox);
        noticeTitle = homeView.findViewById(R.id.noticeTitle);
        noticeBrief = homeView.findViewById(R.id.noticeBrief);
        meVersion = homeView.findViewById(R.id.meVersion);

        homeView.findViewById(R.id.btnLaunch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ensureFloat();
                } catch (Throwable t) {
                    CrashLog.log(MainActivity.this, "btnLaunch", t);
                }
            }
        });
        homeView.findViewById(R.id.accountCard).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
        homeView.findViewById(R.id.btnFloatPerm).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ensureFloat();
            }
        });
        homeView.findViewById(R.id.btnImportHelp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TstDialog.show(MainActivity.this, "导入说明",
                        "1. 在游戏中把光标对准命令方块\n2. 开启悬浮窗，点击「部署」\n3. 悬浮窗会自动把命令粘贴进游戏输入框并发送\n\n首次使用请先开启悬浮窗权限。",
                        "知道了", null, null, null);
            }
        });
        homeView.findViewById(R.id.noticeCard).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFeature("notice");
            }
        });

        meVersion.setVisibility(View.GONE);
        cardIn(homeView.findViewById(R.id.btnLaunch), 40);
        cardIn(homeView.findViewById(R.id.noticeCard), 120);
    }

    // ===== 百宝箱面板 =====

    private View buildToyBox() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(0xFFf3f5f8);
        col.setPadding(dp(14), dp(14), dp(14), dp(24));
        col.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        for (final String[] f : FEATURES) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
            gd.setColor(0xFFFFFFFF);
            gd.setCornerRadius(dp(12));
            gd.setStroke(dp(1), 0xFFe2e8f0);
            row.setBackground(gd);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = dp(8);
            row.setLayoutParams(rlp);
            final String key = f[0];
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showFeature(key);
                }
            });

            TextView n = new TextView(this);
            n.setText(f[1]);
            n.setTextSize(14.5f);
            n.setTextColor(0xFF1f2937);
            n.setTypeface(n.getTypeface(), 1);
            row.addView(n);

            TextView s = new TextView(this);
            s.setText(f[2]);
            s.setTextSize(12f);
            s.setTextColor(0xFF5b6675);
            s.setPadding(0, dp(2), 0, 0);
            row.addView(s);

            col.addView(row);
        }

        // 终端入口（列表底部，低调小字）
        LinearLayout termRow = new LinearLayout(this);
        termRow.setOrientation(LinearLayout.VERTICAL);
        termRow.setGravity(Gravity.CENTER_HORIZONTAL);
        termRow.setPadding(0, dp(16), 0, dp(4));
        TextView term = new TextView(this);
        term.setText("终端");
        term.setTextSize(12f);
        term.setTextColor(0xFF94a3b8);
        term.setPadding(dp(10), dp(6), dp(10), dp(6));
        term.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFeature("terminal");
            }
        });
        termRow.addView(term);
        col.addView(termRow);

        return col;
    }

    // ===== 设置面板 =====

    private void initSettings() {
        sAvatar = settingsView.findViewById(R.id.avatarText);
        sName = settingsView.findViewById(R.id.accountName);
        sSub = settingsView.findViewById(R.id.accountSub);
        sBtnAccount = settingsView.findViewById(R.id.btnAccount);
        sVersionValue = settingsView.findViewById(R.id.versionValue);
        sVersionValue.setText("v" + VersionManager.BuildConfigHolder.VERSION_NAME
                + "（build " + VersionManager.BuildConfigHolder.VERSION_CODE + "）");

        settingsView.findViewById(R.id.accountCard).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAccountTap();
            }
        });
        sBtnAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAccountTap();
            }
        });
        settingsView.findViewById(R.id.rowSource).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBrowser("https://github.com/severuszx/TST");
            }
        });
        settingsView.findViewById(R.id.rowPrivacy).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFeature("privacy");
            }
        });
        settingsView.findViewById(R.id.rowFloat).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ensureFloat();
            }
        });
        settingsView.findViewById(R.id.rowHelp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TstDialog.show(MainActivity.this, "导入说明",
                        "1. 进游戏后打开聊天栏，把光标对准命令方块\n2. 开启悬浮窗（设置里可再开启权限）\n3. 点击悬浮球「部署」，自动逐块粘贴命令并发送\n\n悬浮球会自动跳过重复的命令方块。",
                        "知道了", null, null, null);
            }
        });
        refreshAccount();
    }

    private void onAccountTap() {
        if (LoginManager.isLoggedIn(this)) {
            TstDialog.show(this, "退出登录",
                    "确定要退出当前官网账号吗？退出后部分功能（积分、个人中心）不可用。",
                    "退出", new TstDialog.Btn() {
                        @Override
                        public void onClick() {
                            LoginManager.logout(MainActivity.this);
                            Toast.makeText(MainActivity.this, "已退出登录", Toast.LENGTH_SHORT).show();
                            refreshAccount();
                        }
                    }, "取消", null);
        } else {
            showLoginDialog();
        }
    }

    private void refreshAccount() {
        boolean logged = LoginManager.isLoggedIn(this);
        if (settingsView == null) return;
        if (logged) {
            String email = LoginManager.email(this);
            String name = email == null ? "" : email;
            sName.setText(name.isEmpty() ? "已登录" : name);
            sSub.setText(R.string.account_logged_sub);
            sBtnAccount.setText(R.string.login_logout);
            String ch = name.trim().isEmpty() ? "T" : name.trim().substring(0, 1).toUpperCase(Locale.ROOT);
            sAvatar.setText(ch);
        } else {
            sName.setText(R.string.login_btn);
            sSub.setText(R.string.account_tap_to_login);
            sBtnAccount.setText(R.string.login_btn);
            sAvatar.setText("T");
        }
        // 主页账号卡同步
        if (accountName != null) {
            if (logged) {
                String email = LoginManager.email(this);
                String name = email == null ? "" : email;
                accountName.setText(name.isEmpty() ? "已登录" : name);
                accountSub.setText(R.string.account_logged_sub);
                btnLogin.setText(R.string.login_logout);
                String ch = name.trim().isEmpty() ? "T" : name.trim().substring(0, 1).toUpperCase(Locale.ROOT);
                avatarText.setText(ch);
            } else {
                accountName.setText(R.string.login_btn);
                accountSub.setText(R.string.account_tap_to_login);
                btnLogin.setText(R.string.login_btn);
                avatarText.setText("T");
            }
        }
    }

    private void showLoginDialog() {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        View v = getLayoutInflater().inflate(R.layout.login_dialog, null);
        dialog.setContentView(v);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_glass_card);
            dialog.getWindow().setDimAmount(0.5f);
        }
        final EditText emailEl = v.findViewById(R.id.loginEmail);
        final EditText codeEl = v.findViewById(R.id.loginCode);
        final Button sendBtn = v.findViewById(R.id.loginSendCode);
        final Button confirmBtn = v.findViewById(R.id.loginConfirm);
        final Button cancelBtn = v.findViewById(R.id.loginCancel);
        final TextView msg = v.findViewById(R.id.loginMsg);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                sendBtn.setEnabled(false);
                sendBtn.setText(R.string.login_sending);
                LoginManager.sendCode(email, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                msg.setVisibility(View.VISIBLE);
                                msg.setText(s);
                                if (ok) {
                                    startCountdown(sendBtn);
                                } else {
                                    sendBtn.setEnabled(true);
                                    sendBtn.setText(R.string.login_send_code);
                                }
                            }
                        });
                    }
                });
            }
        });

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = emailEl.getText().toString().trim();
                final String code = codeEl.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !email.contains("@")) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_email);
                    return;
                }
                if (code.length() != 6) {
                    msg.setVisibility(View.VISIBLE);
                    msg.setText(R.string.login_need_code);
                    return;
                }
                confirmBtn.setEnabled(false);
                LoginManager.verify(email, code, new LoginManager.Callback() {
                    @Override
                    public void onResult(boolean ok, String s, JSONObject data) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                confirmBtn.setEnabled(true);
                                if (ok && data != null) {
                                    LoginManager.save(MainActivity.this,
                                            data.optString("token"),
                                            data.optString("email"),
                                            data.optString("uid"));
                                    msg.setText(R.string.login_success);
                                    dialog.dismiss();
                                    Toast.makeText(MainActivity.this, R.string.login_success, Toast.LENGTH_SHORT).show();
                                    refreshAccount();
                                    LoginManager.whoami(MainActivity.this, null);
                                } else {
                                    msg.setText(getString(R.string.login_failed, s == null ? "" : s));
                                }
                            }
                        });
                    }
                });
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void startCountdown(final Button btn) {
        final int[] left = {60};
        btn.setText(getString(R.string.login_countdown, left[0]));
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                left[0]--;
                if (left[0] <= 0) {
                    btn.setEnabled(true);
                    btn.setText(R.string.login_send_code);
                } else {
                    btn.setText(getString(R.string.login_countdown, left[0]));
                    ui.postDelayed(this, 1000);
                }
            }
        }, 1000);
    }

    // ===== 悬浮窗 / 无障碍 =====

    private void ensureFloat() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            TstDialog.show(this, "需要悬浮窗权限",
                    "开启悬浮窗后，进游戏会有一个悬浮球，对准命令方块点它即可自动逐块粘贴部署。\n\n现在去系统设置里允许「The Slow Tide」显示在其他应用上层。",
                    "去开启", new TstDialog.Btn() {
                        @Override
                        public void onClick() {
                            try {
                                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:" + getPackageName())));
                            } catch (Exception e) {
                                startActivity(new Intent(Settings.ACTION_SETTINGS));
                            }
                        }
                    }, "稍后", null);
            return;
        }
        startService(new Intent(this, FloatService.class));
        Toast.makeText(this, "悬浮窗已开启，进游戏对准命令方块点击悬浮球开始部署", Toast.LENGTH_SHORT).show();
    }

    private boolean accessibilityOn() {
        try {
            String enabled = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return enabled != null && enabled.contains(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    // ===== 时钟 + 下载进度 =====

    private void startTicker() {
        if (ticking) return;
        ticking = true;
        ticker.post(runTicker);
    }

    private void stopTicker() {
        ticking = false;
        ticker.removeCallbacks(runTicker);
    }

    private final Runnable runTicker = new Runnable() {
        @Override
        public void run() {
            if (!ticking) return;
            try {
                String t = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss", Locale.CHINA).format(new Date());
                if (clock != null) clock.setText(t);
                updateLaunchSub();
                refreshDownloads();
            } catch (Throwable ignored) {
            }
            ticker.postDelayed(this, 1000);
        }
    };

    private void updateLaunchSub() {
        if (launchSub == null) return;
        boolean f = Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this);
        boolean a = accessibilityOn();
        if (f && a) launchSub.setText("悬浮窗已就绪 · 无障碍已开启 · 进游戏对准命令方块");
        else if (f) launchSub.setText("悬浮窗已就绪 · 无障碍未开启（点击悬浮球仍可手动部署）");
        else launchSub.setText(R.string.launch_btn_sub);
    }

    private void refreshDownloads() {
        if (downloadBox == null) return;
        List<DownloadProbe.Item> items = DownloadProbe.active(this);
        downloadBox.removeAllViews();
        if (items.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(R.string.home_downloads_empty);
            empty.setTextColor(0xFF5b6675);
            empty.setTextSize(12f);
            empty.setPadding(0, 8, 0, 8);
            downloadBox.addView(empty);
            return;
        }
        for (DownloadProbe.Item it : items) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_btn_ghost);
            card.setPadding(14, 10, 14, 10);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = 8;
            card.setLayoutParams(lp);

            TextView name = new TextView(this);
            name.setText(it.name);
            name.setTextColor(0xFF1f2937);
            name.setTextSize(12.5f);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            card.addView(name);

            ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(100);
            bar.setProgress(it.progress);
            bar.setProgressDrawable(getResources().getDrawable(R.drawable.progress_bar));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
            blp.topMargin = dp(6);
            bar.setLayoutParams(blp);
            card.addView(bar);

            TextView st = new TextView(this);
            st.setText(it.status);
            st.setTextColor(0xFF5b6675);
            st.setTextSize(11f);
            st.setPadding(0, dp(3), 0, 0);
            card.addView(st);

            downloadBox.addView(card);
        }
    }

    // ===== 公告 =====

    private void loadNotices() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(NOTICES_URL).openConnection();
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(12000);
                    conn.setRequestMethod("GET");
                    int code = conn.getResponseCode();
                    if (code != 200) return;
                    InputStream is = conn.getInputStream();
                    BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    conn.disconnect();
                    final JSONArray arr = new JSONObject(sb.toString()).optJSONArray("items");
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            renderTopNotice(arr);
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    private void renderTopNotice(JSONArray arr) {
        if (arr == null || arr.length() == 0 || noticeTitle == null) return;
        JSONObject n = arr.optJSONObject(0);
        if (n == null) return;
        String title = n.optString("title", "");
        String date = n.optString("date", "");
        String body = n.optString("body", "");
        noticeTitle.setText((date.isEmpty() ? "" : date + "  ") + title);
        noticeBrief.setText(body);
    }

    // ===== 云端版本检查 =====

    private void checkUpdateSilent() {
        VersionManager.check(this, new VersionManager.CheckCallback() {
            @Override
            public void onResult(final boolean hasNew, final JSONObject info, String error) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!hasNew) {
                            Toast.makeText(MainActivity.this, "已是最新版本 v" + VersionManager.BuildConfigHolder.VERSION_NAME, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        String note = info.optString("note", "");
                        final String ver = info.optString("versionName", "");
                        final String url = info.optString("url", "");
                        TstDialog.show(MainActivity.this, "发现新版本 v" + ver,
                                note + "\n\n下载安装包将直接在软件内进行，进度见主页「下载」。",
                                "去下载", new TstDialog.Btn() {
                                    @Override
                                    public void onClick() {
                                        VersionManager.openDownload(MainActivity.this, url);
                                    }
                                }, "稍后", null);
                    }
                });
            }
        });
    }

    // ===== 功能页 WebView =====

    private WebView createWebView() {
        WebView wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        wv.setBackgroundColor(0xFFf3f5f8);
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePath, WebChromeClient.FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePath;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if ("site".equals(featureKey)) injectLoginState();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("file://")) {
                    view.loadUrl(url);
                    return true;
                }
                return false;
            }
        });
        wv.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                startInternalDownload(url);
            }
        });
        wv.addJavascriptInterface(new TstJs(), "Tst");
        return wv;
    }

    private void injectLoginState() {
        if (webView == null || !LoginManager.isLoggedIn(this)) return;
        String token = LoginManager.token(this);
        String email = LoginManager.email(this);
        String uid = LoginManager.uid(this);
        if (token == null) return;
        final String js = "try{"
                + "localStorage.setItem('tst_token','" + jsEsc(token) + "');"
                + "localStorage.setItem('tst_email','" + jsEsc(email == null ? "" : email) + "');"
                + "localStorage.setItem('tst_uid','" + jsEsc(uid == null ? "" : uid) + "');"
                + "}catch(e){}";
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript(js, null);
            }
        });
    }

    private String jsEsc(String s) {
        return s.replace("\\", "\\\\").replace("'", "\\'");
    }

    private void startInternalDownload(String url) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setAllowedOverMetered(true);
            req.setAllowedOverRoaming(true);
            String fileName = "TST_" + System.currentTimeMillis() + "." + guessExt(url);
            if (Build.VERSION.SDK_INT >= 29) {
                req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, fileName);
            } else {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            }
            long id = dm.enqueue(req);
            DownloadProbe.track(this, id, url, fileName);
            Toast.makeText(this, "已开始下载（进度见主页）", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "下载失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private String guessExt(String url) {
        String path = Uri.parse(url).getPath();
        if (path != null) {
            String ext = path.substring(path.lastIndexOf('.') + 1);
            if (ext.length() <= 5 && ext.matches("[a-zA-Z0-9]+")) return ext;
        }
        return "bin";
    }

    // ===== JS 桥 =====

    private class TstJs {
        @android.webkit.JavascriptInterface
        public void copy(final String text) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("tst", text));
                        Toast.makeText(MainActivity.this, "已复制到剪贴板", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "复制失败", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void toast(final String text) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void download(String url) {
            startInternalDownload(url);
        }

        @android.webkit.JavascriptInterface
        public void openWeb(final String url) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (webView != null) webView.loadUrl(url);
                }
            });
        }

        // 终端联动：跳转到另一个功能页（在同一窗口内切换）
        @android.webkit.JavascriptInterface
        public void openFeature(final String key) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        showFeature(key);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public String httpGet(final String url) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 TST-Client");
                String tok = LoginManager.token(MainActivity.this);
                if (tok != null && !tok.isEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer " + tok);
                }
                int code = conn.getResponseCode();
                if (code != 200) return "{\"error\":\"HTTP " + code + "\"}";
                InputStream is = conn.getInputStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
                r.close();
                conn.disconnect();
                return sb.toString();
            } catch (Exception e) {
                return "{\"error\":\"" + e.getMessage() + "\"}";
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
                try {
                    getContentResolver().takePersistableUriPermission(data.getData(),
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && currentPanel == webView && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        if (currentPanel != homeView) {
            showHome();
            return;
        }
        super.onBackPressed();
    }

    private void openBrowser(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "无法打开", Toast.LENGTH_SHORT).show();
        }
    }

    // ===== PCL2 式卡片进场 =====

    private void cardIn(View v, int delay) {
        if (Build.VERSION.SDK_INT < 21) return;
        v.setAlpha(0f);
        v.setScaleX(0.92f);
        v.setScaleY(0.92f);
        v.setTranslationY(24f);
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(320).setStartDelay(delay)
                .setInterpolator(new OvershootInterpolator(1.1f)).start();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAccount();
        updateLaunchSub();
        startTicker();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopTicker();
    }

    @Override
    protected void onDestroy() {
        stopTicker();
        if (webView != null) {
            content.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
