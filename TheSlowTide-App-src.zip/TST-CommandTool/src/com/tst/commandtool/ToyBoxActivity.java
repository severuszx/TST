package com.tst.commandtool;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 百宝箱：收纳全部功能（PCL 风格二级页）。
 * 网格 + 入场动画；网站直达/官网入口放在底部角落。
 */
public class ToyBoxActivity extends Activity {

    private static final String[][] FEATURES = {
            {"tools", "指令工具", "拆分 · 部署", "\u270E"},
            {"lib", "指令库", "云端同步", "\u25A4"},
            {"selector", "选区助手", "坐标选择器", "\u25A1"},
            {"base64", "Base64 互译", "图片 · 文本", "\u25E7"},
            {"jsonview", "JSON 显示", "T 显 · 文本组件", "{}"},
            {"snowball", "雪球菜单", "T 显生成", "\u2744"},
            {"mcdownload", "MC 下载", "版本 · PCL2", "\u2193"},
            {"skin", "皮肤查询", "ID → 皮肤 · 3D", "\u25C9"},
            {"seed", "种子查找", "遗迹 · 结构", "\u25C6"},
            {"terminal", "终端", "调试码 · 版本下载", ">_"},
            {"notice", "公告", "版本更新", "\u2691"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFFf3f5f8);
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(0), dp(16), dp(24));
        root.addView(col);

        // 顶栏：返回 + 标题
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, dp(14), 0, dp(8));
        col.addView(bar);

        TextView back = new TextView(this);
        back.setText("‹ 返回");
        back.setTextSize(15);
        back.setTextColor(0xFF0f172a);
        back.setPadding(0, dp(6), dp(14), dp(6));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back);

        TextView title = new TextView(this);
        title.setText("百宝箱");
        title.setTextSize(18);
        title.setTextColor(0xFF1f2937);
        title.setTypeface(title.getTypeface(), 1);
        bar.addView(title);

        // 网格
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        col.addView(grid);

        LinearLayout row = null;
        for (int i = 0; i < FEATURES.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                grid.addView(row);
            }
            final String key = FEATURES[i][0];
            final String name = FEATURES[i][1];
            final String sub = FEATURES[i][2];
            final String icon = FEATURES[i][3];
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(dp(10), dp(16), dp(10), dp(16));
            GradientDrawable gd = new GradientDrawable();
            gd.setColor(0xFFFFFFFF);
            gd.setCornerRadius(dp(14));
            gd.setStroke(dp(1), 0xFFe2e8f0);
            card.setBackground(gd);
            card.setElevation(dp(2));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i % 2 == 0) clp.rightMargin = dp(6);
            else clp.leftMargin = dp(6);
            clp.topMargin = dp(8);
            card.setLayoutParams(clp);
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent it = new Intent(ToyBoxActivity.this, FeatureActivity.class);
                    it.putExtra(FeatureActivity.EXTRA_FEATURE, key);
                    startActivity(it);
                }
            });
            row.addView(card);

            TextView iv = new TextView(this);
            iv.setText(icon);
            iv.setTextSize(24);
            iv.setGravity(Gravity.CENTER);
            card.addView(iv);

            TextView n = new TextView(this);
            n.setText(name);
            n.setTextSize(14);
            n.setTextColor(0xFF1f2937);
            n.setTypeface(n.getTypeface(), 1);
            n.setGravity(Gravity.CENTER);
            n.setPadding(0, dp(6), 0, 0);
            card.addView(n);

            TextView s = new TextView(this);
            s.setText(sub);
            s.setTextSize(11);
            s.setTextColor(0xFF5b6675);
            s.setGravity(Gravity.CENTER);
            s.setPadding(0, dp(2), 0, 0);
            s.setMaxLines(1);
            card.addView(s);

            // 入场动画（依次上滑淡入）
            if (Build.VERSION.SDK_INT >= 21) {
                card.setAlpha(0f);
                card.setTranslationY(dp(14));
                card.animate().alpha(1f).translationY(0f).setDuration(260).setStartDelay(i * 40).start();
            }
        }

        // 底部角落：网站直达 / 官网（低调小字）
        LinearLayout corner = new LinearLayout(this);
        corner.setOrientation(LinearLayout.HORIZONTAL);
        corner.setGravity(Gravity.CENTER);
        corner.setPadding(0, dp(22), 0, 0);
        col.addView(corner);

        TextView sites = new TextView(this);
        sites.setText("网站直达");
        sites.setTextSize(12);
        sites.setTextColor(0xFF5b6675);
        sites.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable sg = new GradientDrawable();
        sg.setColor(0xFFFFFFFF);
        sg.setCornerRadius(dp(8));
        sg.setStroke(dp(1), 0xFFe2e8f0);
        sites.setBackground(sg);
        sites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open("sites");
            }
        });
        corner.addView(sites);

        TextView site = new TextView(this);
        site.setText("官网");
        site.setTextSize(12);
        site.setTextColor(0xFF5b6675);
        site.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable g2 = new GradientDrawable();
        g2.setColor(0xFFFFFFFF);
        g2.setCornerRadius(dp(8));
        g2.setStroke(dp(1), 0xFFe2e8f0);
        site.setBackground(g2);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.leftMargin = dp(8);
        site.setLayoutParams(slp);
        site.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open("site");
            }
        });
        corner.addView(site);
        return root;
    }

    private void open(String key) {
        Intent it = new Intent(this, FeatureActivity.class);
        it.putExtra(FeatureActivity.EXTRA_FEATURE, key);
        startActivity(it);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
