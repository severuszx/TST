package com.tst.commandtool;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 百宝箱（PCL2 式列表页）：功能列表，纯文字行，无图标符号。
 * 终端入口在列表底部（低调小字），避免显眼。
 */
public class ToyBoxActivity extends Activity {

    private static final String[][] FEATURES = {
            {"tools", "指令工具", "指令拆分 · 自动部署"},
            {"lib", "指令库", "云端指令模板"},
            {"selector", "选区助手", "坐标选择器"},
            {"base64", "Base64 互译", "图片 · 文本互转"},
            {"jsonview", "JSON 显示", "文本组件 · T 显"},
            {"snowball", "雪球菜单", "T 显生成"},
            {"mcdownload", "MC 下载", "版本下载 · PCL2 启动器"},
            {"skin", "皮肤查询", "正版 ID 查询 · 3D 预览"},
            {"seed", "种子查找", "遗迹 · 结构"},
            {"notice", "公告", "版本更新说明"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFFf3f5f8);
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(0), dp(14), dp(24));
        root.addView(col);

        // 顶栏：返回 + 标题
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, dp(12), 0, dp(10));
        col.addView(bar);

        TextView back = new TextView(this);
        back.setText("‹ 返回");
        back.setTextSize(15);
        back.setTextColor(0xFF0f172a);
        back.setPadding(0, dp(6), dp(14), dp(6));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back);

        TextView title = new TextView(this);
        title.setText("百宝箱");
        title.setTextSize(18);
        title.setTextColor(0xFF1f2937);
        title.setTypeface(title.getTypeface(), 1);
        bar.addView(title);

        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.setVerticalScrollBarEnabled(false);
        col.addView(sc);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sc.addView(list);

        for (int i = 0; i < FEATURES.length; i++) {
            final String key = FEATURES[i][0];
            final String name = FEATURES[i][1];
            final String sub = FEATURES[i][2];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            GradientDrawable gd = new GradientDrawable();
            gd.setColor(0xFFFFFFFF);
            gd.setCornerRadius(dp(12));
            gd.setStroke(dp(1), 0xFFe2e8f0);
            row.setBackground(gd);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = dp(8);
            row.setLayoutParams(rlp);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent it = new Intent(ToyBoxActivity.this, FeatureActivity.class);
                    it.putExtra(FeatureActivity.EXTRA_FEATURE, key);
                    startActivity(it);
                }
            });
            list.addView(row);

            TextView n = new TextView(this);
            n.setText(name);
            n.setTextSize(14.5f);
            n.setTextColor(0xFF1f2937);
            n.setTypeface(n.getTypeface(), 1);
            row.addView(n);

            TextView s = new TextView(this);
            s.setText(sub);
            s.setTextSize(12);
            s.setTextColor(0xFF5b6675);
            s.setPadding(0, dp(2), 0, 0);
            row.addView(s);

            if (Build.VERSION.SDK_INT >= 21) {
                row.setAlpha(0f);
                row.setTranslationY(dp(12));
                row.animate().alpha(1f).translationY(0f).setDuration(240).setStartDelay(i * 30).start();
            }
        }

        // 终端入口（低调小字，放列表底部）
        TextView term = new TextView(this);
        term.setText("终端");
        term.setTextSize(12.5f);
        term.setTextColor(0xFF5b6675);
        term.setGravity(Gravity.CENTER);
        term.setPadding(dp(0), dp(10), dp(0), dp(10));
        GradientDrawable tg = new GradientDrawable();
        tg.setColor(0xFFFFFFFF);
        tg.setCornerRadius(dp(10));
        tg.setStroke(dp(1), 0xFFe2e8f0);
        term.setBackground(tg);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(4);
        term.setLayoutParams(tlp);
        term.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(ToyBoxActivity.this, FeatureActivity.class);
                it.putExtra(FeatureActivity.EXTRA_FEATURE, "terminal");
                startActivity(it);
            }
        });
        list.addView(term);
        return root;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
