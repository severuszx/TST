package com.tst.commandtool;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 自绘弹窗（PCL 风格）：半透明遮罩 + 白色圆角卡片 + 弹出动画。
 * 替换系统 AlertDialog，所有弹窗统一走这里。
 */
public class TstDialog {

    public interface Btn {
        void onClick();
    }

    public static Dialog show(Context c, String title, String message, String btnText, final Btn btn) {
        return show(c, title, message, btnText, btn, null, null);
    }

    public static Dialog show(Context c, String title, String message,
                              String btnText, final Btn btn,
                              String btn2Text, final Btn btn2) {
        try {
            return build(c, title, message, btnText, btn, btn2Text, btn2);
        } catch (Throwable t) {
            // 自绘弹窗任何异常都不允许崩掉应用：回退系统提示
            CrashLog.log(c, "TstDialog.show", t);
            try {
                android.widget.Toast.makeText(c, title + "\n" + message, android.widget.Toast.LENGTH_LONG).show();
            } catch (Exception ignored) {
            }
            return null;
        }
    }

    private static Dialog build(Context c, String title, String message,
                                String btnText, final Btn btn,
                                String btn2Text, final Btn btn2) {
        final Dialog d = new Dialog(c, android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setDimAmount(0.5f);
        }

        FrameLayout root = new FrameLayout(c);
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(c, 20), dp(c, 22), dp(c, 20), dp(c, 16));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(0xFFFFFFFF);
        gd.setCornerRadius(dp(c, 18));
        gd.setStroke(dp(c, 1), 0xFFe2e8f0);
        card.setBackground(gd);
        card.setElevation(dp(c, 12));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(c, 304), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        card.setLayoutParams(lp);
        root.addView(card);

        TextView t = new TextView(c);
        t.setText(title);
        t.setTextColor(0xFF1f2937);
        t.setTextSize(17);
        t.setTypeface(t.getTypeface(), 1);
        card.addView(t);

        ScrollView sv = new ScrollView(c);
        TextView msg = new TextView(c);
        msg.setText(message);
        msg.setTextColor(0xFF5b6675);
        msg.setTextSize(13.5f);
        msg.setLineSpacing(0, 1.2f);
        sv.addView(msg);
        LinearLayout.LayoutParams svlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 210));
        card.addView(sv, svlp);

        LinearLayout btns = new LinearLayout(c);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.END);
        btns.setPadding(0, dp(c, 14), 0, 0);
        card.addView(btns);

        if (btn2Text != null) {
            TextView b2 = mkBtn(c, btn2Text, false);
            btns.addView(b2);
            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    d.dismiss();
                    if (btn2 != null) btn2.onClick();
                }
            });
        }
        TextView b1 = mkBtn(c, btnText, true);
        btns.addView(b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                if (btn != null) btn.onClick();
            }
        });

        d.setContentView(root);

        if (Build.VERSION.SDK_INT >= 21) {
            card.setAlpha(0f);
            card.setScaleX(0.92f);
            card.setScaleY(0.92f);
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
        }
        d.show();
        return d;
    }

    private static TextView mkBtn(Context c, String text, boolean primary) {
        TextView b = new TextView(c);
        b.setText(text);
        b.setTextSize(14);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(c, 18), dp(c, 10), dp(c, 18), dp(c, 10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(c, 10);
        b.setLayoutParams(lp);
        GradientDrawable g = new GradientDrawable();
        if (primary) {
            g.setColor(0xFF0f172a);
            b.setTextColor(Color.WHITE);
        } else {
            g.setColor(0xFFffffff);
            b.setTextColor(0xFF1f2937);
            g.setStroke(dp(c, 1), 0xFFe2e8f0);
        }
        g.setCornerRadius(dp(c, 10));
        b.setBackground(g);
        return b;
    }

    private static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
}
