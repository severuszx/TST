# The Slow Tide 客户端（开源）
官网: https://theslowtide.pages.dev
后端 API: https://theslowtidefk.pages.dev/api
客户端开源仓库: https://github.com/severuszx/TST

## 构建
1. 将 android-sdk 解压到 build_apk/android-sdk（platforms/android-33 + build-tools/33.0.2）
2. 使用 JDK8 运行 build_apk/build.ps1，产物为 build_apk/out/TheSlowTide.apk
3. release.keystore 为服务器签名密钥，不随源码分发，可自行生成（alias=tst）

## 版本
当前版本 1.4.8（versionCode 13）。版本号由 AndroidManifest.xml 经 build.ps1 自动注入。
历史版本客户端只能通过终端调试码下载：Download theslowtide <版本号>

## 功能
主页/百宝箱/功能页/设置 顶栏导航（PCL2 式）；设置独立页收纳登录、版本、仓库、隐私、权限、导入说明。
百宝箱：指令工具 / 指令库 / 选区助手 / Base64 互译 / JSON 显示 / 雪球菜单 / MC 下载 / 皮肤查询 / 种子查找 / 终端 / 公告
