package com.tst.commandtool;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;


public class DeployEngine {

    public interface Listener {
        void onStateChanged();
        void onLog(String line);
    }

    private static DeployEngine instance;
    private final List<Listener> listeners = new ArrayList<>();
    private CommandTask task;
    private Context appContext;
    private boolean autoVerify = true;
    private String targetMode = "循环";
    private String targetCond = "无条件";
    private String targetRedstone = "需要红石";

    private DeployEngine() {
    }

    public static synchronized DeployEngine get() {
        if (instance == null) instance = new DeployEngine();
        return instance;
    }

    public void attach(Context c) {
        if (appContext == null) appContext = c.getApplicationContext();
        try {
            org.json.JSONObject s = TaskStore.loadSettings(c);
            autoVerify = s.optBoolean("autoVerify", true);
            targetMode = s.optString("targetMode", "循环");
            targetCond = s.optString("targetCond", "无条件");
            targetRedstone = s.optString("targetRedstone", "需要红石");
        } catch (Exception ignored) {
        }
    }

    public void addListener(Listener l) {
        if (!listeners.contains(l)) listeners.add(l);
    }

    public void removeListener(Listener l) {
        listeners.remove(l);
    }

    public CommandTask getTask() {
        return task;
    }

    public void setTask(CommandTask t) {
        this.task = t;
        if (t != null) t.state = CommandTask.STATE_IDLE;
        notifyChanged();
    }

    public boolean isRunning() {
        return task != null && task.state == CommandTask.STATE_RUNNING;
    }

    public void start() {
        if (task == null || task.blocks.isEmpty()) return;
        task.state = CommandTask.STATE_RUNNING;
        task.currentIndex = 0;
        log("start: block 1/" + task.total());
        notifyChanged();
    }

    public void resume() {
        if (task == null) return;
        task.state = CommandTask.STATE_RUNNING;
        log("resumed");
        notifyChanged();
    }

    public void pause() {
        if (task == null) return;
        task.state = CommandTask.STATE_PAUSED;
        log("paused");
        notifyChanged();
    }

    public void toggle() {
        if (task == null) return;
        if (task.state == CommandTask.STATE_RUNNING) pause();
        else if (task.state == CommandTask.STATE_PAUSED || task.state == CommandTask.STATE_IDLE || task.state == CommandTask.STATE_ERROR) resume();
    }

    public void markBlockOk() {
        if (task == null) return;
        log("block " + (task.currentIndex + 1) + "/" + task.total() + " ok");
        task.currentIndex++;
        if (task.currentIndex >= task.blocks.size()) {
            task.state = CommandTask.STATE_DONE;
            log("all done");
        } else {
            log("aim next block: " + (task.currentIndex + 1) + "/" + task.total());
        }
        notifyChanged();
    }

    public void markBlockFail(String reason) {
        if (task == null) return;
        task.state = CommandTask.STATE_ERROR;
        log("fail: " + reason);
        notifyChanged();
    }

    public void retryBlock() {
        if (task == null) return;
        task.state = CommandTask.STATE_RUNNING;
        log("retry block " + (task.currentIndex + 1));
        notifyChanged();
    }

    public String currentBlock() {
        return task == null ? null : task.currentBlock();
    }

    public boolean isAutoVerify() {
        return autoVerify;
    }

    public String targetMode() {
        return targetMode;
    }

    public String targetCond() {
        return targetCond;
    }

    public String targetRedstone() {
        return targetRedstone;
    }

    public void log(String line) {
        for (Listener l : listeners) {
            try {
                l.onLog(line);
            } catch (Exception ignored) {
            }
        }
    }

    private void notifyChanged() {
        for (Listener l : listeners) {
            try {
                l.onStateChanged();
            } catch (Exception ignored) {
            }
        }
    }
}
